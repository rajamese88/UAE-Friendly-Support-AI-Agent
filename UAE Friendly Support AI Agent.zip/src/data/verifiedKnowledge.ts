export interface VerifiedSource {
  name: string;
  url: string;
  verifiedDate: string;
}

export interface VerifiedModuleKnowledge {
  verifiedFacts: string[];
  sources: VerifiedSource[];
}

export const VERIFIED_KNOWLEDGE: Record<string, VerifiedModuleKnowledge> = {
  passport_visa: {
    verifiedFacts: [
      "Different nationalities must follow their respective embassy or consulate's official procedures (e.g. Indian passports via BLS International / CGI Dubai; Pakistani passports via NADRA online portal or Pak Consulate Dubai; Philippines passports via MWO / POLO Dubai). Processes and fees are country-specific.",
      "UAE entry permits and residency visas for Dubai are managed by GDRFA (General Directorate of Residency and Foreigners Affairs) / Amer Centres; other Emirates are managed by the Federal Authority for Identity, Citizenship, Customs and Port Security (ICP).",
      "Passports generally must have at least 6 months of validity before traveling or applying for UAE residency visas.",
      "Overstaying a UAE visa incurs daily fines set by UAE ICP/GDRFA rules (AED 50 per day after grace period expiration). Always check official ICP or GDRFA portals for exact status."
    ],
    sources: [
      { name: "Federal Authority for Identity, Citizenship, Customs & Port Security (ICP)", url: "https://icp.gov.ae", verifiedDate: "October 2026" },
      { name: "General Directorate of Residency and Foreigners Affairs Dubai (GDRFA)", url: "https://www.gdrfad.gov.ae", verifiedDate: "October 2026" },
      { name: "BLS International UAE (Indian Passports)", url: "https://www.blsindiavisa-uae.com", verifiedDate: "October 2026" }
    ]
  },
  transport_travel: {
    verifiedFacts: [
      "Dubai Public Transport (Metro, Bus, Tram, Marine) is operated by the Roads and Transport Authority (RTA) and uses contactless Nol smart cards (Silver, Gold, Blue, or Red paper ticket). Cash is not accepted onboard buses or metro gates.",
      "Intercity buses between Emirates (e.g., Dubai to Abu Dhabi Route E100 from Al Ghubaiba and Route E101 from Ibn Battuta) cost approximately AED 25 per trip and require a Nol card with sufficient balance.",
      "Abu Dhabi public buses operate under the Integrated Transport Centre (ITC) and use the Hafilat smart card. Real-time journey planning is available via the official Darbi app.",
      "Live schedules, traffic delays, and platform changes vary continuously. Always verify live departure times on official apps: RTA S'hail (Dubai) or ITC Darbi (Abu Dhabi)."
    ],
    sources: [
      { name: "Roads and Transport Authority Dubai (RTA) - S'hail", url: "https://www.rta.ae", verifiedDate: "October 2026" },
      { name: "Integrated Transport Centre Abu Dhabi (ITC) - Darbi", url: "https://darbi.itc.gov.ae", verifiedDate: "October 2026" },
      { name: "Sharjah Roads and Transport Authority (SRTA)", url: "https://www.srta.gov.ae", verifiedDate: "October 2026" }
    ]
  },
  worker_support: {
    verifiedFacts: [
      "Under UAE Federal Decree-Law No. 33 of 2021 and Wages Protection System (WPS) regulations, employers must pay wages on the due date; payments delayed by more than 14 days trigger automatic MOHRE company restrictions.",
      "Labour claims with financial values under AED 100,000 are completely exempt from judicial and court fees at all stages of litigation (Article 4 of Federal Decree-Law No. 33 of 2021).",
      "Withholding an employee's passport is strictly prohibited under UAE Ministerial Circular No. 267 of 2002 and the UAE Penal Code. A passport is the legal property of the issuing government.",
      "Tawjeeh (تواجه) centres are official MOHRE-licensed guidance centres providing free worker rights advice and mediation in over 15 languages across the UAE."
    ],
    sources: [
      { name: "Ministry of Human Resources and Emiratisation (MOHRE)", url: "https://www.mohre.gov.ae", verifiedDate: "October 2026" },
      { name: "UAE Federal Decree-Law No. 33 of 2021 on Regulation of Labour Relations", url: "https://www.mohre.gov.ae/en/laws-and-regulations/labour-law.aspx", verifiedDate: "October 2026" }
    ]
  },
  everyday_uae: {
    verifiedFacts: [
      "Dubai residential tenancy contracts must be registered with the Dubai Land Department under the Ejari system. In Abu Dhabi, tenancy contracts are registered via the Tawtheeq system.",
      "Health insurance is mandatory by law for all residents in Dubai (enforced by Dubai Health Authority - DHA) and Abu Dhabi (enforced by Department of Health - DoH).",
      "Emergency telephone numbers across the UAE are standardized: Police (Crime/Emergency): 999, Ambulance: 998, Fire / Civil Defence: 997, Non-Emergency Police / Labour Welfare: 901.",
      "Utility connections (Electricity and Water) are managed by DEWA in Dubai (Emergency 991), ADDC in Abu Dhabi (800-2332), and SEWA in Sharjah."
    ],
    sources: [
      { name: "Dubai Land Department - Ejari Services", url: "https://dubailand.gov.ae", verifiedDate: "October 2026" },
      { name: "Dubai Health Authority (DHA)", url: "https://www.dha.gov.ae", verifiedDate: "October 2026" },
      { name: "UAE Government Portal - Emergency Services", url: "https://u.ae/en/information-and-services/justice-safety-and-the-law/handling-emergencies", verifiedDate: "October 2026" }
    ]
  }
};

// Aliases for compatibility
VERIFIED_KNOWLEDGE.delayed_salary = VERIFIED_KNOWLEDGE.worker_support;
VERIFIED_KNOWLEDGE.contract_issue = VERIFIED_KNOWLEDGE.worker_support;
VERIFIED_KNOWLEDGE.official_service = VERIFIED_KNOWLEDGE.everyday_uae;

export interface GuidanceActionStep {
  stepNumber: number;
  title: string;
  description: string;
  urgency: 'immediate' | 'next_step' | 'official_filing';
  practicalTip: string;
}

export interface GuidanceRequiredDocument {
  name: string;
  whyNeeded: string;
  howToGet: string;
}

export interface FallbackGuidancePlan {
  summary: string;
  plainExplanation: string;
  actionSteps: GuidanceActionStep[];
  requiredDocuments: GuidanceRequiredDocument[];
  verifiedFacts: string[];
  practicalAdvice: string[];
  uncertainties: string;
  disclaimer: string;
}

export function getFallbackGuidance(key: string, language: string, _details?: any): FallbackGuidancePlan {
  const normalizedKey = key === 'delayed_salary' || key === 'contract_issue' ? 'worker_support' : key;

  const responses: Record<string, Record<string, FallbackGuidancePlan>> = {
    passport_visa: {
      en: {
        summary: "Official guidance on UAE residency visas, visit visas, and national passport renewal services.",
        plainExplanation: "National passport renewals depend strictly on your country of citizenship (e.g., BLS for India, NADRA/Consulate for Pakistan). UAE residency and visit visas are issued federally by ICP or by GDRFA (Amer) in Dubai.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "Identify your official issuing authority",
            description: "For national passports, check your home country embassy portal. For UAE visa extensions and entry permits, check ICP (icp.gov.ae) or GDRFA (gdrfad.gov.ae).",
            urgency: "immediate",
            practicalTip: "Never pay unauthorized middlemen or third-party booking agents for standard appointments."
          },
          {
            stepNumber: 2,
            title: "Prepare passport photos and required documents",
            description: "Gather current passport, Emirates ID or visa copy, and 2 passport photos with white background.",
            urgency: "next_step",
            practicalTip: "Ensure your passport has at least 6 months validity before planned travel."
          },
          {
            stepNumber: 3,
            title: "Book official appointment online",
            description: "Book an appointment directly through the authorized service provider (e.g., BLS International or Consulate online appointment portal).",
            urgency: "official_filing",
            practicalTip: "Print your appointment confirmation and bring original documents."
          }
        ],
        requiredDocuments: [
          { name: "Current Original Passport", whyNeeded: "Required for physical verification and stamping.", howToGet: "Your personal travel document." },
          { name: "Valid UAE Visa Copy / Emirates ID", whyNeeded: "To verify residency status in the UAE.", howToGet: "From ICP UAE smart app or physical card." },
          { name: "Standard White-Background Photos", whyNeeded: "Required for passport and visa processing.", howToGet: "From any registered photo studio." }
        ],
        verifiedFacts: [
          "Different nationalities must use their own country's accredited diplomatic service; fees and timelines vary.",
          "Overstaying UAE visas incurs a daily fine after the grace period under ICP regulations.",
          "Passports must usually have at least 6 months remaining validity for international travel."
        ],
        practicalAdvice: [
          "Keep high-resolution photos of your passport and visa on your phone at all times.",
          "Begin renewal procedures 2 to 3 months before your passport or visa expiry date."
        ],
        uncertainties: "Exact appointment availability and fees vary by nationality and embassy workload.",
        disclaimer: "This guidance is provided for informational support only and does not constitute official consular or government representation."
      },
      ar: {
        summary: "إرشادات تجديد جوازات السفر وتأشيرات الإقامة في دولة الإمارات.",
        plainExplanation: "تجديد جواز السفر يعتمد على سفارة أو قنصلية بلدك المعتمدة في الدولة (مثل BLS للهند، أو القنصلية الباكستانية/نادرا). أما تأشيرات الدخول والإقامة فتخضع للهيئة الاتحادية للهوية (ICP) أو إقامة دبي (GDRFA).",
        actionSteps: [
          {
            stepNumber: 1,
            title: "تحديد الجهة الرسمية المعتمدة",
            description: "لجوازات السفر، ادخل على الموقع الرسمي لسفارة أو قنصلية بلدك في الإمارات. لتأشيرات الإقامة، راجع بوابة ICP (icp.gov.ae) أو إقامة دبي (gdrfad.gov.ae).",
            urgency: "immediate",
            practicalTip: "احذر دفع أي مبالغ لوسطاء أو مكاتب غير مرخصة لحجز المواعيد الرسمية."
          },
          {
            stepNumber: 2,
            title: "تجهيز المستندات والصور الشخصية",
            description: "جهّز الجواز الأصلي الحالي، وصورة الهوية الإماراتية أو التأشيرة، وصورتين شخصيتين بخلفية بيضاء.",
            urgency: "next_step",
            practicalTip: "تأكد من بقاء 6 أشهر على الأقل في صلاحية جواز سفرك قبل التخطيط للسفر."
          },
          {
            stepNumber: 3,
            title: "حجز موعد رسمي إلكتروني",
            description: "احجز موعداً مسبقاً عبر المنصة الرسمية للسفارة أو مركز تقديم الخدمة المعتمد واحفظ إشعار الموعد.",
            urgency: "official_filing",
            practicalTip: "اطبع تأكيد الموعد واصطحب معك الوثائق الأصلية."
          }
        ],
        requiredDocuments: [
          { name: "جواز السفر الأصلي الحالي", whyNeeded: "مطلوب للتحقق والمطابقة وتثبيت التأشيرة.", howToGet: "وثيقة السفر الشخصية الموجودة بحوزتك." },
          { name: "صورة التأشيرة / الهوية الإماراتية", whyNeeded: "لإثبات صفة الإقامة القانونية في الإمارات.", howToGet: "تطبيق الهوية الذكي (ICP App) أو البطاقة الأصلية." },
          { name: "صور شخصية بخلفية بيضاء", whyNeeded: "مطلوبة لمعاملات الجوازات والتأشيرات.", howToGet: "من أي استوديو تصوير معتمد." }
        ],
        verifiedFacts: [
          "تختلف الرسوم والمدد باختلاف جنسية المتعامل والبعثة الدبلوماسية المعنية.",
          "البقاء في الدولة بعد انتهاء مدة السماح يعرض المتعامل لغرامات مالية يومية (50 درهماً يومياً وفق لوائح ICP).",
          "يشترط ألا تقل صلاحية الجواز عن 6 أشهر لمعظم إجراءات السفر والإقامة."
        ],
        practicalAdvice: [
          "احتفظ دائماً بنسخة إلكترونية واضحة من جواز السفر والتأشيرة على هاتفك.",
          "ابدأ إجراءات التجديد قبل شهرين إلى ثلاثة أشهر من انتهاء الصلاحية."
        ],
        uncertainties: "تختلف مواعيد العمل والرسوم بحسب الدولة وسفارتها المعنية.",
        disclaimer: "هذا الدليل يقدم إرشادات عامة ولا يمثل صفة قانونية أو دبلوماسية رسمية."
      },
      ta: {
        summary: "பாஸ்போர்ட் புதுப்பித்தல் மற்றும் அமீரக விசா குறித்த அதிகாரப்பூர்வ வழிகாட்டல்.",
        plainExplanation: "பாஸ்போர்ட் புதுப்பித்தல் உங்கள் தாய்நாட்டு தூதரகத்தை பொறுத்தது (எ.கா: இந்தியாவுக்கு BLS, பாகிஸ்தானுக்கு தூதரகம்). அமீரக விசாக்கள் ICP அல்லது துபாய் GDRFA மூலம் பெறப்படுகிறது.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "சரியான தூதரக மையத்தை தேர்வு செய்யவும்",
            description: "இந்திய பாஸ்போர்ட்டுக்கு BLS International இணையதளம் செல்லவும். அமீரக விசாவுக்கு ICP இணையதளம் செல்லவும்.",
            urgency: "immediate",
            practicalTip: "இடைத்தரகர்களிடம் பணம் கொடுத்து ஏமாற வேண்டாம்."
          },
          {
            stepNumber: 2,
            title: "ஆவணங்கள் மற்றும் புகைப்படங்களை தயார் செய்யவும்",
            description: "தற்போதைய பாஸ்போர்ட், எமிரேட்ஸ் ஐடி நகல், வெள்ளை பின்னணி புகைப்படங்களை தயார் வைக்கவும்.",
            urgency: "next_step",
            practicalTip: "பாஸ்போர்ட் செல்லுபடியாகும் காலம் குறைந்தது 6 மாதங்கள் இருக்க வேண்டும்."
          },
          {
            stepNumber: 3,
            title: "அதிகாரப்பூர்வ முன்பதிவு (Appointment) பெறவும்",
            description: "BLS அல்லது தூதரக இணையதளத்தில் நேரடியாக நேரம் ஒதுக்கி செல்லவும்.",
            urgency: "official_filing",
            practicalTip: "முன்பதிவு ரசீதை அச்சிட்டு எடுத்துச் செல்லவும்."
          }
        ],
        requiredDocuments: [
          { name: "அசல் பாஸ்போர்ட்", whyNeeded: "சரிபார்ப்புக்கு தேவை.", howToGet: "உங்களிடம் உள்ள ஆவணம்." },
          { name: "எமிரேட்ஸ் ஐடி / விசா நகல்", whyNeeded: "அமீரக வாசஸ்தலத்தை நிரூபிக்க.", howToGet: "ICP செயலி அல்லது அட்டை." },
          { name: "வெள்ளை பின்னணி புகைப்படங்கள்", whyNeeded: "விண்ணப்ப படிவத்திற்கு.", howToGet: "புகைப்பட நிலையத்தில் பெறலாம்." }
        ],
        verifiedFacts: [
          "ஒவ்வொரு நாட்டினருக்கும் தூதரக கட்டணங்களும் விதிமுறைகளும் மாறுபடும்.",
          "விசா காலம் முடிந்த பின் தங்குவது நாள் ஒன்றுக்கு அபராதம் விதிக்கப்படும்.",
          "பயணம் செய்ய பாஸ்போர்ட்டில் 6 மாத காலம் மீதம் இருக்க வேண்டும்."
        ],
        practicalAdvice: [
          "பாஸ்போர்ட் காலாவதியாகும் 3 மாதங்களுக்கு முன்பே புதுப்பிக்க விண்ணப்பிக்கவும்.",
          "பாஸ்போர்ட் நகலை போனில் பாதுகாப்பாக வைத்திருக்கவும்."
        ],
        uncertainties: "தூதரக கட்டணங்கள் அந்தந்த நாட்டின் நாணய மாற்று விகிதத்தை பொறுத்து மாறுபடலாம்.",
        disclaimer: "இது விழிப்புணர்வு வழிகாட்டல் மட்டுமே; தூதரக அல்லது அரசு முடிவல்ல."
      },
      ml: {
        summary: "പാസ്‌പോർട്ട് പുതുക്കലും യുഎഇ വിസയും സംബന്ധിച്ച ഔദ്യോഗിക വിവരങ്ങൾ.",
        plainExplanation: "പാസ്‌പോർട്ട് പുതുക്കൽ അതാത് രാജ്യത്തിന്റെ എംബസി സേവനങ്ങൾ വഴിയാണ് (ഇന്ത്യക്കാർക്ക് BLS, പാകിസ്ഥാൻകാർക്ക് കോൺസുലേറ്റ്). വിസകൾ ICP / GDRFA വഴിയാണ് കൈകാര്യം ചെയ്യുന്നത്.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "ഔദ്യോഗിക സേവന കേന്ദ്രം കണ്ടെത്തുക",
            description: "ഇന്ത്യൻ പാസ്‌പോർട്ടിന് BLS ഇന്റർനാഷണൽ വഴിയും യുഎഇ വിസയ്ക്ക് ICP/GDRFA വഴിയും സമീപിക്കുക.",
            urgency: "immediate",
            practicalTip: "വ്യാജ ഏജന്റുമാർക്ക് പണം നൽകരുത്."
          },
          {
            stepNumber: 2,
            title: "രേഖകളും ഫോട്ടോകളും കരുതുക",
            description: "നിലവിലെ പാസ്‌പോർട്ട്, വിസ കോപ്പി, എമിറേറ്റ്സ് ഐഡി, വെള്ള പശ്ചാത്തലത്തിലുള്ള ഫോട്ടോ എന്നിവ കരുതുക.",
            urgency: "next_step",
            practicalTip: "പാസ്‌പോർട്ടിന് കുറഞ്ഞത് 6 മാസം കാലാവധി ഉണ്ടായിരിക്കണം."
          },
          {
            stepNumber: 3,
            title: "ഓൺലൈൻ അപ്പോയിന്റ്മെന്റ് എടുക്കുക",
            description: "BLS അല്ലെങ്കിൽ എംബസി വെബ്സൈറ്റിൽ നേരിട്ട് സമയം ബുക്ക് ചെയ്യുക.",
            urgency: "official_filing",
            practicalTip: "അപ്പോയിന്റ്മെന്റ് സ്ലിപ്പും ഒറിജിനൽ രേഖകളും കൊണ്ടുപോകുക."
          }
        ],
        requiredDocuments: [
          { name: "ഒറിജിനൽ പാസ്‌പോർട്ട്", whyNeeded: "പരിശോധനയ്ക്കായി.", howToGet: "നിങ്ങളുടെ പക്കലുള്ള രേഖ." },
          { name: "എമിറേറ്റ്സ് ഐഡി / വിസ പകർപ്പ്", whyNeeded: "താമസ പദവി തെളിയിക്കാൻ.", howToGet: "ICP ആപ്പ് അല്ലെങ്കിൽ കാർഡ്." },
          { name: "പാസ്‌പോർട്ട് ഫോട്ടോ", whyNeeded: "അപേക്ഷയ്ക്ക്.", howToGet: "സ്റ്റുഡിയോയിൽ നിന്ന് എടുക്കുക." }
        ],
        verifiedFacts: [
          "ഓരോ രാജ്യക്കാർക്കും എംബസി ഫീസും നടപടികളും വ്യത്യസ്തമാണ്.",
          "വിസ കാലാവധി കഴിഞ്ഞുള്ള താമസത്തിന് ദിവസേന പിഴ ഈടാക്കും.",
          "യാത്രയ്ക്ക് പാസ്‌പോർട്ടിന് 6 മാസ കാലാവധി നിർബന്ധമാണ്."
        ],
        practicalAdvice: [
          "കാലാവധി തീരുന്നതിന് 3 മാസം മുൻപ് തന്നെ പുതുക്കാൻ അപേക്ഷിക്കുക.",
          "രേഖകളുടെ ഫോട്ടോകൾ ഫോണിൽ സൂക്ഷിക്കുക."
        ],
        uncertainties: "അപ്പോയിന്റ്മെന്റ് തീയതികൾ എംബസിയുടെ തിരക്കനുസരിച്ച് മാറാം.",
        disclaimer: "ഇത് വിവരങ്ങൾ നൽകുന്നതിനായുള്ള മാർഗ്ഗനിർദ്ദേശം മാത്രമാണ്."
      },
      hi: {
        summary: "पासपोर्ट नवीनीकरण एवं यूएई वीजा से संबंधित आधिकारिक मार्गदर्शन।",
        plainExplanation: "पासपोर्ट नवीनीकरण आपके देश के दूतावास नियमों पर निर्भर करता है (भारतीय नागरिकों के लिए BLS, पाकिस्तानी नागरिकों के लिए दूतावास)। यूएई वीजा ICP या GDRFA द्वारा जारी होते हैं।",
        actionSteps: [
          {
            stepNumber: 1,
            title: "सही आधिकारिक केंद्र चुनें",
            description: "भारतीय पासपोर्ट के लिए BLS इंटरनेशनल और यूएई वीजा के लिए ICP पोर्टल पर जाएं।",
            urgency: "immediate",
            practicalTip: "अनधिकृत दलालों या एजेंटों से बचें।"
          },
          {
            stepNumber: 2,
            title: "दस्तावेज व फोटो तैयार करें",
            description: "मूल पासपोर्ट, एमिरेट्स आईडी व वीजा कॉपी, और 2 पासपोर्ट फोटो (सफेद बैकग्राउंड) रखें।",
            urgency: "next_step",
            practicalTip: "यात्रा के लिए पासपोर्ट में कम से कम 6 महीने की वैधता होनी चाहिए।"
          },
          {
            stepNumber: 3,
            title: "आधिकारिक वेबसाइट पर अपॉइंटमेंट लें",
            description: "BLS या दूतावास पोर्टल पर जाकर सीधे तारीख और समय बुक करें।",
            urgency: "official_filing",
            practicalTip: "अपॉइंटमेंट की रसीद प्रिंट करके साथ ले जाएं।"
          }
        ],
        requiredDocuments: [
          { name: "मूल पासपोर्ट", whyNeeded: "सत्यापन एवं नवीनीकरण हेतु।", howToGet: "आपके पास उपलब्ध दस्तावेज।" },
          { name: "एमिरेट्स आईडी / वीजा कॉपी", whyNeeded: "यूएई निवास प्रमाण के लिए।", howToGet: "ICP ऐप या कार्ड।" },
          { name: "सफेद बैकग्राउंड फोटो", whyNeeded: "आवेदन पत्र के लिए।", howToGet: "फोटो स्टूडियो से प्राप्त करें।" }
        ],
        verifiedFacts: [
          "हर देश के दूतावास के नियम और शुल्क अलग होते हैं।",
          "वीजा अवधि समाप्त होने के बाद रहने पर दैनिक जुर्माना लगता है।",
          "अंतरराष्ट्रीय यात्रा के लिए 6 महीने का पासपोर्ट अनिवार्य है।"
        ],
        practicalAdvice: [
          "पासपोर्ट समाप्त होने से 3 माह पहले नवीनीकरण शुरू करें।",
          "पासपोर्ट की फोटो हमेशा फोन में सुरक्षित रखें।"
        ],
        uncertainties: "अपॉइंटमेंट की उपलब्धता दूतावास की व्यस्तता पर निर्भर करती है।",
        disclaimer: "यह सामान्य जानकारी है, कोई आधिकारिक सरकारी फैसला नहीं।"
      },
      ur: {
        summary: "پاسپورٹ کی تجدید اور یو اے ای ویزا سے متعلق سرکاری رہنمائی۔",
        plainExplanation: "پاسپورٹ کی تجدید آپ کے اپنے ملک کے سفارت خانے کے قوانین کے مطابق ہوتی ہے (مثلاً پاکستانی شہریوں کے لیے نادرا پورٹل یا قونصل خانہ)۔ یو اے ای ویزا ICP یا GDRFA جاری کرتا ہے۔",
        actionSteps: [
          {
            stepNumber: 1,
            title: "متعلقہ سرکاری ادارہ معلوم کریں",
            description: "پاکستانی پاسپورٹ کے لیے قونصل خانہ یا آن لائن پورٹل پر جائیں۔ ویزے کے لیے ICP پورٹل دیکھیں۔",
            urgency: "immediate",
            practicalTip: "غیر مجاز ایجنٹوں کو فالتو رقم نہ دیں۔"
          },
          {
            stepNumber: 2,
            title: "ضروری کاغذات اور تصاویر تیار کریں",
            description: "اصل پاسپورٹ، شناختی کارڈ، اماراتی ویزا کاپی اور تصاویر ساتھ رکھیں۔",
            urgency: "next_step",
            practicalTip: "سفر کے لیے پاسپورٹ کی مدت کم از کم 6 ماہ ہونی چاہیے۔"
          },
          {
            stepNumber: 3,
            title: "سرکاری اپائنٹمنٹ حاصل کریں",
            description: "سفارت خانے کی ویب سائٹ سے آن لائن ٹائم حاصل کریں اور اصل دستاویزات لے کر جائیں۔",
            urgency: "official_filing",
            practicalTip: "اپائنٹمنٹ کی سلپ پرنٹ کر لیں۔"
          }
        ],
        requiredDocuments: [
          { name: "اصل پاسپورٹ", whyNeeded: "تصدیق کے لیے ضروری ہے۔", howToGet: "آپ کے پاس موجود دستاویز۔" },
          { name: "اماراتی ویزا کاپی / شناختی کارڈ", whyNeeded: "رہائشی ثبوت کے لیے۔", howToGet: "ICP ایپ سے حاصل کریں۔" },
          { name: "پاسپورٹ سائز تصاویر", whyNeeded: "فارم کے لیے۔", howToGet: "سٹوڈیو سے بنوائیں۔" }
        ],
        verifiedFacts: [
          "ہر ملک کے سفارت خانے کی فیس اور اوقات کار مختلف ہوتے ہیں۔",
          "ویزا کی میعاد ختم ہونے پر یومیہ جرمانہ عائد ہوتا ہے۔",
          "بین الاقوامی سفر کے لیے 6 ماہ کا پاسپورٹ لازمی ہے۔"
        ],
        practicalAdvice: [
          "پاسپورٹ کی میعاد ختم ہونے سے 3 ماہ قبل تجدید کروائیں۔",
          "کاغذات کی تصویریں موبائل میں رکھیں۔"
        ],
        uncertainties: "فیس اور اپائنٹمنٹ کا وقت متعلقہ سفارت خانے کے شیڈول پر منحصر ہے۔",
        disclaimer: "یہ صرف عام معلوماتی رہنمائی ہے۔"
      }
    },
    transport_travel: {
      en: {
        summary: "Public transport and travel guidance across Dubai, Abu Dhabi, and Northern Emirates.",
        plainExplanation: "Dubai public transit (Metro, Bus, Tram) requires a Nol card operated by RTA. Intercity buses link Dubai, Abu Dhabi, and Sharjah. Abu Dhabi buses use Hafilat cards managed by ITC.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "Obtain the correct transit smart card",
            description: "For Dubai and Intercity buses, purchase an RTA Silver Nol Card at any metro station. For Abu Dhabi, buy a Hafilat card.",
            urgency: "immediate",
            practicalTip: "Maintain at least AED 15 to AED 25 balance on your Nol card before boarding intercity buses."
          },
          {
            stepNumber: 2,
            title: "Use official journey planner apps for live timings",
            description: "Download RTA S'hail for Dubai routes or ITC Darbi for Abu Dhabi. Live traffic cannot be estimated by static tools.",
            urgency: "next_step",
            practicalTip: "Check Metro operating hours (Monday to Thursday usually 5:00 AM – midnight; Friday until 1:00 AM)."
          },
          {
            stepNumber: 3,
            title: "Board intercity buses at official terminals",
            description: "Route E100 departs from Al Ghubaiba to Abu Dhabi; Route E101 departs from Ibn Battuta. Fares are approx AED 25.",
            urgency: "official_filing",
            practicalTip: "Arrive 15 minutes early during peak morning and weekend hours."
          }
        ],
        requiredDocuments: [
          { name: "RTA Nol Card (Silver or Gold)", whyNeeded: "Mandatory payment method for Dubai Metro and buses.", howToGet: "Any Dubai Metro ticket office or vending machine." },
          { name: "Hafilat Card (for Abu Dhabi)", whyNeeded: "Payment method for Abu Dhabi city and regional buses.", howToGet: "Abu Dhabi bus stations and kiosks." },
          { name: "RTA S'hail / Darbi App", whyNeeded: "Official journey planner for real-time bus arrivals.", howToGet: "App Store or Google Play Store." }
        ],
        verifiedFacts: [
          "Cash is strictly not accepted on Dubai Metro or RTA buses; Nol card is mandatory.",
          "Intercity bus trips between Dubai and Abu Dhabi cost approximately AED 25 per direction using a Nol card.",
          "Live departures and delays are updated in real time on the official RTA S'hail and ITC Darbi portals."
        ],
        practicalAdvice: [
          "Download offline metro maps on your phone for quick reference without internet.",
          "Avoid rush hour crowds (7:00–9:00 AM and 5:30–7:30 PM) when traveling with luggage."
        ],
        uncertainties: "Live transit delays, road detours, and exact bus frequency must be verified on official RTA/ITC apps.",
        disclaimer: "This guidance is provided for journey planning assistance only. Fares and timetables are subject to official RTA/ITC operational updates."
      },
      ar: {
        summary: "دليل المواصلات العامة في دبي وأبوظبي والتنقل بين الإمارات.",
        plainExplanation: "وسائل النقل العام في دبي (المترو، الحافلات، الترام) تتطلب بطاقة نول (Nol) التابعة لهيئة الطرق والمواصلات، ولا يُقبل الدفع النقدي. الحافلات بين المدن تربط دبي بأبوظبي والشارقة. وفي أبوظبي تستخدم بطاقات حافلات التابعة لمركز النقل المتكامل (درب).",
        actionSteps: [
          {
            stepNumber: 1,
            title: "الحصول على البطاقة الذكية المناسبة",
            description: "لرحلات دبي والحافلات بين المدن، اشترِ بطاقة نول الفضية من أي محطة مترو. وللتنقل داخل أبوظبي اشترِ بطاقة حافلات.",
            urgency: "immediate",
            practicalTip: "تأكد من وجود رصيد لا يقل عن 25 درهماً في بطاقة نول قبل ركوب الحافلات بين المدن."
          },
          {
            stepNumber: 2,
            title: "استخدام التطبيقات الرسمية لمعرفة المواعيد الحية",
            description: "حمّل تطبيق سهيل (S'hail) لمسارات دبي أو تطبيق درب (Darbi) لمسارات أبوظبي لمتابعة مواعيد الحافلات ومستجدات الحركة المرورية بدقة.",
            urgency: "next_step",
            practicalTip: "تأكد من ساعات عمل المترو (من الاثنين إلى الخميس حتى منتصف الليل، ويومي الجمعة والسبت حتى الواحدة صباحاً)."
          },
          {
            stepNumber: 3,
            title: "ركوب الحافلات بين المدن من المحطات الرئيسية",
            description: "ينطلق الخط E100 من محطة الغبيبة بدبي إلى أبوظبي، والخط E101 من محطة ابن بطوطة. تبلغ التكلفة نحو 25 درهماً للاتجاه الواحد.",
            urgency: "official_filing",
            practicalTip: "يُفضل الوصول قبل موعد الانطلاق بـ 15 دقيقة في أوقات الذروة وعطلات نهاية الأسبوع."
          }
        ],
        requiredDocuments: [
          { name: "بطاقة نول الذكية (الفضية)", whyNeeded: "وسيلة الدفع الإلزامية لمترو وحافلات دبي.", howToGet: "من أجهزة بيع التذاكر أو مكاتب محطات المترو." },
          { name: "بطاقة حافلات (داخل أبوظبي)", whyNeeded: "وسيلة الدفع لحافلات مدينة أبوظبي والضواحي.", howToGet: "من محطات الحافلات وأجهزة التعبئة بأبوظبي." },
          { name: "تطبيق سهيل / تطبيق درب", whyNeeded: "لتخطيط المسارات ومتابعة زمن الوصول الفعلي.", howToGet: "متجر التطبيقات (Google Play / App Store)." }
        ],
        verifiedFacts: [
          "لا يُقبل الدفع النقدي إطلاقاً داخل الحافلات أو بوابات المترو؛ استخدام البطاقة الذكية إلزامي.",
          "تبلغ تكلفة الرحلة بالحافلة بين دبي وأبوظبي نحو 25 درهماً لكل اتجاه باستخدام بطاقة نول.",
          "تُحدث الجداول الزمنية ومواعيد الرحلات بصورة حية عبر التطبيقات الرسمية لهيئة الطرق (سهيل ودرب)."
        ],
        practicalAdvice: [
          "احفظ خريطة المترو على هاتفك للاستخدام السريع دون الحاجة للإنترنت.",
          "تجنب أوقات الذروة (7:00-9:00 صباحاً و5:30-7:30 مساءً) إذا كنت تحمل حقائب سفر."
        ],
        uncertainties: "تتغير حركة المرور وأزمنة التقاطر المباشرة بحسب الازدحام المروري وظروف الطريق.",
        disclaimer: "هذه الإرشادات مخصصة لتسهيل تخطيط الرحلات؛ وتخضع المواعيد والرسوم للتحديثات الرسمية التشغيلية."
      },
      ta: {
        summary: "துபாய் மெட்ரோ, பஸ், மற்றும் எமிரேட்ஸ் இடையேயான போக்குவரத்து வழிகாட்டல்.",
        plainExplanation: "துபாயில் பயணம் செய்ய Nol அட்டை அவசியம்; பணம் வாங்கப்பட மாட்டாது. அபுதாபிக்கு செல்ல E100 (அல் குபைபா) அல்லது E101 (இப்ன் பத்தூதா) பஸ்கள் உள்ளன. அபுதாபியில் ஹபிலாத் (Hafilat) அட்டை தேவை.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "Nol அல்லது Hafilat அட்டையை பெறவும்",
            description: "மெட்ரோ அல்லது பஸ் நிலையங்களில் சில்வர் Nol அட்டை வாங்கவும். அபுதாபி பயணத்திற்கு குறைந்தது 25 திர்ஹம் இருப்பு வைக்கவும்.",
            urgency: "immediate",
            practicalTip: "பஸ்ஸில் பணம் வாங்க மாட்டார்கள்; அட்டை மட்டுமே செல்லும்."
          },
          {
            stepNumber: 2,
            title: "RTA S'hail செயலியில் நேரத்தை சரிபார்க்கவும்",
            description: "நேரலை பஸ் வரும் நேரங்களை அறிய S'hail செயலியை பதிவிறக்கவும்.",
            urgency: "next_step",
            practicalTip: "மெட்ரோ நேரம் காலை 5:00 மணி முதல் நள்ளிரவு வரை இயங்கும்."
          },
          {
            stepNumber: 3,
            title: "அபுதாபி பஸ் நிலையத்திலிருந்து ஏறவும்",
            description: "அல் குபைபாவிலிருந்து E100 அல்லது இப்ன் பத்தூதாவிலிருந்து E101 பஸ் எடுக்கலாம் (கட்டணம் சுமார் AED 25).",
            urgency: "official_filing",
            practicalTip: "வார இறுதி நாட்களில் கூட்டமாக இருக்கும் என்பதால் முன்கூட்டியே செல்லவும்."
          }
        ],
        requiredDocuments: [
          { name: "Nol அட்டை (சில்வர்)", whyNeeded: "மெட்ரோ மற்றும் பஸ் கட்டணம் செலுத்த.", howToGet: "மெட்ரோ நிலைய டிக்கெட் கவுண்டர்." },
          { name: "RTA S'hail செயலி", whyNeeded: "பஸ் வரும் நேரத்தை துல்லியமாக அறிய.", howToGet: "கூகுள் ப்ளே ஸ்டோர்." },
          { name: "ஹபிலாத் அட்டை (அபுதாபிக்கு)", whyNeeded: "அபுதாபி உள்ளூர் பஸ்களுக்கு.", howToGet: "அபுதாபி பஸ் நிலையம்." }
        ],
        verifiedFacts: [
          "துபாய் பஸ்களில் ரொக்கப் பணம் வாங்கப்பட மாட்டாது; Nol அட்டை கட்டாயம்.",
          "துபாயிலிருந்து அபுதாபி செல்ல பஸ் கட்டணம் சுமார் 25 திர்ஹம் ஆகும்.",
          "நேரடி பஸ் தகவல்களை RTA S'hail அல்லது ITC Darbi-யில் பார்க்கலாம்."
        ],
        practicalAdvice: [
          "Nol அட்டையில் எப்போதும் 15 திர்ஹத்திற்கு மேல் இருப்பு வைத்திருக்கவும்.",
          "பீக் நேரங்களில் (காலை 7-9, மாலை 5-7) பயணத்தை திட்டமிட்டு மேற்கொள்ளவும்."
        ],
        uncertainties: "சாலையில் டிராபிக் காரணமாக பஸ் நேரம் மாறுபடலாம்.",
        disclaimer: "இது போக்குவரத்து வழிகாட்டல் மட்டுமே; கட்டணங்களை RTA இணையதளத்தில் உறுதி செய்யவும்."
      },
      ml: {
        summary: "ദുബായ് മെട്രോ, നോൽ കാർഡ്, ഇന്റർസിറ്റി ബസ് യാത്രാ വിവരങ്ങൾ.",
        plainExplanation: "ദുബായിൽ യാത്ര ചെയ്യാൻ RTA നോൽ കാർഡ് നിർബന്ധമാണ്. ദുബായിൽ നിന്ന് അബുദാബിയിലേക്ക് E100 (അൽ ഗുബൈബ), E101 (ഇബ്ൻ ബത്തൂത്ത) ബസുകൾ ലഭ്യമാണ്. അബുദാബിയിൽ ഹഫിലത്ത് കാർഡ് ഉപയോഗിക്കണം.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "നോൽ കാർഡ് വാങ്ങുക",
            description: "ഏതെങ്കിലും മെട്രോ സ്റ്റേഷനിൽ നിന്ന് സിൽവർ നോൽ കാർഡ് വാങ്ങുക. അബുദാബി യാത്രയ്ക്ക് കാർഡിൽ മിനിമം 25 ദിർഹം വേണം.",
            urgency: "immediate",
            practicalTip: "ബസിൽ പണം സ്വീകരിക്കില്ല, കാർഡ് മാത്രമാണ് ഉപയോഗിക്കേണ്ടത്."
          },
          {
            stepNumber: 2,
            title: "RTA S'hail ആപ്പിൽ സമയം പരിശോധിക്കുക",
            description: "കൃത്യമായ ബസ് സമയം അറിയാൻ ഔദ്യോഗിക S'hail ആപ്പ് ഉപയോഗിക്കുക.",
            urgency: "next_step",
            practicalTip: "മെട്രോ സമയം രാവിലെ 5:00 മുതൽ അർദ്ധരാത്രി വരെയാണ്."
          },
          {
            stepNumber: 3,
            title: "ഇന്റർസിറ്റി ബസുകളിൽ യാത്ര ചെയ്യുക",
            description: "ഇബ്ൻ ബത്തൂത്തയിൽ നിന്ന് E101 അല്ലെങ്കിൽ അൽ ഗുബൈബയിൽ നിന്ന് E100 ബസ് കയറുക.",
            urgency: "official_filing",
            practicalTip: "വാരാന്ത്യങ്ങളിൽ തിരക്ക് കൂടുതലായിരിക്കും."
          }
        ],
        requiredDocuments: [
          { name: "സിൽവർ നോൽ കാർഡ്", whyNeeded: "യാത്രാ നിരക്ക് നൽകാൻ.", howToGet: "മെട്രോ സ്റ്റേഷൻ." },
          { name: "S'hail ആപ്പ്", whyNeeded: "തത്സമയ ബസ് സമയം അറിയാൻ.", howToGet: "പ്ലേ സ്റ്റോർ." },
          { name: "ഹഫിലത്ത് കാർഡ്", whyNeeded: "അബുദാബി ബസുകൾക്ക്.", howToGet: "അബുദാബി ബസ് സ്റ്റാൻഡ്." }
        ],
        verifiedFacts: [
          "ദുബായ് ബസുകളിൽ ക്യാഷ് എടുക്കില്ല, നോൽ കാർഡ് നിർബന്ധമാണ്.",
          "ദുബായ്-അബുദാബി ഇന്റർസിറ്റി ബസ് ചാർജ് ഏകദേശം 25 ദിർഹമാണ്.",
          "തത്സമയ വിവരങ്ങൾ RTA ഔദ്യോഗിക ആപ്പിൽ ലഭ്യമാണ്."
        ],
        practicalAdvice: [
          "കാർഡിൽ എപ്പോഴും കുറഞ്ഞത് 15 ദിർഹം ബാലൻസ് സൂക്ഷിക്കുക.",
          "ഓഫ്ലൈൻ മെട്രോ മാപ്പ് ഫോണിൽ സൂക്ഷിക്കുക."
        ],
        uncertainties: "ട്രാഫിക് അനുസരിച്ച് ബസ് സമയങ്ങളിൽ മാറ്റം വരാം.",
        disclaimer: "ഇത് യാത്രാ മാർഗ്ഗനിർദ്ദേശം മാത്രമാണ്."
      },
      hi: {
        summary: "दुबई मेट्रो, नोल कार्ड एवं अंतर-अमीरात सार्वजनिक परिवहन मार्गदर्शन।",
        plainExplanation: "दुबई में यात्रा के लिए RTA नोल कार्ड अनिवार्य है; बसों में नकद स्वीकार नहीं किया जाता। दुबई से आबू धाबी जाने के लिए E100 (अल घुबैबा) व E101 (इब्न बतूता) बसें उपलब्ध हैं।",
        actionSteps: [
          {
            stepNumber: 1,
            title: "नोल या हाफिलात कार्ड प्राप्त करें",
            description: "मेट्रो स्टेशन से सिल्वर नोल कार्ड लें। आबू धाबी जाने के लिए कम से कम 25 दिरहम बैलेंस रखें।",
            urgency: "immediate",
            practicalTip: "बसों में कैश नहीं चलता, केवल कार्ड से भुगतान होता है।"
          },
          {
            stepNumber: 2,
            title: "RTA S'hail ऐप पर समय जांचें",
            description: "बसों के आने का लाइव समय देखने के लिए S'hail ऐप डाउनलोड करें।",
            urgency: "next_step",
            practicalTip: "मेट्रो सुबह 5:00 बजे से आधी रात तक चलती है।"
          },
          {
            stepNumber: 3,
            title: "आधिकारिक बस टर्मिनल से यात्रा करें",
            description: "इब्न बतूता से E101 या अल घुबैबा से E100 बस पकड़ें (किराया लगभग AED 25)।",
            urgency: "official_filing",
            practicalTip: "सप्ताहांत पर भीड़ अधिक होने के कारण 15 मिनट पहले पहुंचें।"
          }
        ],
        requiredDocuments: [
          { name: "सिल्वर नोल कार्ड", whyNeeded: "मेट्रो व बस किराए के भुगतान हेतु।", howToGet: "मेट्रो स्टेशन काउंटर।" },
          { name: "RTA S'hail ऐप", whyNeeded: "लाइव बस समय देखने हेतु।", howToGet: "गूगल प्ले स्टोर।" },
          { name: "हाफिलात कार्ड", whyNeeded: "आबू धाबी बसों के लिए।", howToGet: "आबू धाबी बस अड्डा।" }
        ],
        verifiedFacts: [
          "दुबई सार्वजनिक परिवहन में नकद स्वीकार नहीं किया जाता; नोल कार्ड अनिवार्य है।",
          "दुबई से आबू धाबी का बस किराया नोल कार्ड द्वारा लगभग 25 दिरहम है।",
          "लाइव समय की जानकारी RTA S'hail एवं ITC Darbi ऐप पर उपलब्ध होती है।"
        ],
        practicalAdvice: [
          "नोल कार्ड में हमेशा कम से कम 15 दिरहम बैलेंस बनाए रखें।",
          "ऑफलाइन मेट्रो मैप अपने फोन में सेव रखें।"
        ],
        uncertainties: "सड़क यातायात के कारण बस समय में बदलाव संभव है।",
        disclaimer: "यह केवल यात्रा सहायता है; आधिकारिक किराए व समय RTA द्वारा निर्धारित हैं।"
      },
      ur: {
        summary: "دبئی میٹرو، نول کارڈ اور انٹرسٹی پبلک ٹرانسپورٹ کی معلومات۔",
        plainExplanation: "دبئی میں سفر کے لیے RTA نول کارڈ لازمی ہے۔ نقد رقم قبول نہیں کی جاتی۔ ابوظہبی کے لیے ابن بطوطہ سے E101 اور الغبیبہ سے E100 بسیں چلتی ہیں۔",
        actionSteps: [
          {
            stepNumber: 1,
            title: "نول کارڈ یا حافلات کارڈ حاصل کریں",
            description: "میٹرو اسٹیشن سے سلور نول کارڈ خریدیں۔ انٹرسٹی سفر کے لیے کم از کم 25 درہم بیلنس رکھیں۔",
            urgency: "immediate",
            practicalTip: "بسوں میں نقد کرایہ نہیں لیا جاتا، صرف کارڈ چلتا ہے۔"
          },
          {
            stepNumber: 2,
            title: "RTA سہیل ایپ پر اوقات چیک کریں",
            description: "بسوں کے آنے کا لائیو وقت دیکھنے کے لیے S'hail ایپ استعمال کریں۔",
            urgency: "next_step",
            practicalTip: "میٹرو صبح 5 بجے سے رات گئے تک چلتی ہے۔"
          },
          {
            stepNumber: 3,
            title: "سرکاری ٹرمینل سے بس لیں",
            description: "ابن بطوطہ سے E101 یا الغبیبہ سے E100 بس لیں (کرایہ تقریباً 25 درہم)۔",
            urgency: "official_filing",
            practicalTip: "چھٹی والے دن وقت سے پہلے پہنچیں۔"
          }
        ],
        requiredDocuments: [
          { name: "سلور نول کارڈ", whyNeeded: "سفر کے کرایے کی ادائیگی کے لیے۔", howToGet: "میٹرو اسٹیشن ٹکٹ کاؤنٹر۔" },
          { name: "سہیل (S'hail) ایپ", whyNeeded: "لائیو بس ٹائمنگ معلوم کرنے کے لیے۔", howToGet: "پلے اسٹور سے۔" },
          { name: "حافلات کارڈ", whyNeeded: "ابوظہبی لوکل بسوں کے لیے۔", howToGet: "ابوظہبی بس سٹینڈ۔" }
        ],
        verifiedFacts: [
          "دبئی بسوں اور میٹرو پر کیش نہیں چلتا، نول کارڈ لازمی ہے۔",
          "دبئی سے ابوظہبی انٹرسٹی بس کا کرایہ تقریباً 25 درہم ہے۔",
          "لائیو شیڈول RTA کی سرکاری ایپ پر دستیاب ہوتا ہے۔"
        ],
        practicalAdvice: [
          "کارڈ میں ہمیشہ مناسب بیلنس رکھیں۔",
          "میٹرو کا نقشہ موبائل میں ڈاؤن لوڈ کر کے رکھیں۔"
        ],
        uncertainties: "ٹریفک کی وجہ سے بس کے پہنچنے میں تاخیر ہو سکتی ہے۔",
        disclaimer: "یہ معلوماتی سفری رہنمائی ہے، سرکاری شیڈول RTA کے تحت ہے۔"
      }
    },
    worker_support: {
      en: {
        summary: "Guidance on UAE worker rights, delayed wages under WPS, and MOHRE complaint procedures.",
        plainExplanation: "Under UAE Federal Decree-Law No. 33 of 2021, wages must be paid on time through the Wages Protection System (WPS). Labour claims under AED 100,000 are 100% exempt from court fees at all litigation stages.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "Document payment records and employment contract",
            description: "Gather your MOHRE electronic labour contract, bank wage statements, and written communications regarding the delay.",
            urgency: "immediate",
            practicalTip: "Do not surrender your original passport; employer passport retention is prohibited by UAE law."
          },
          {
            stepNumber: 2,
            title: "Seek mediation through MOHRE Tawjeeh or helpline",
            description: "Call MOHRE toll-free at 800-60 or visit a licensed Tawjeeh guidance centre for free dispute consultation.",
            urgency: "next_step",
            practicalTip: "Tawjeeh services provide official guidance in multiple languages without filing charges."
          },
          {
            stepNumber: 3,
            title: "File official labour complaint if unresolved",
            description: "Submit a formal wage complaint via MOHRE app or website. If mediation fails within 14 days, MOHRE refers the case to Labour Court.",
            urgency: "official_filing",
            practicalTip: "Cases under AED 100,000 are completely exempt from judicial and legal fees."
          }
        ],
        requiredDocuments: [
          { name: "MOHRE Labour Contract", whyNeeded: "Proves agreed salary, job title, and employment terms.", howToGet: "Download from MOHRE app using Emirates ID." },
          { name: "Bank Statement / WPS Pay Slip", whyNeeded: "Official proof of missing or delayed salary deposits.", howToGet: "From your bank or payroll exchange." },
          { name: "Emirates ID Copy", whyNeeded: "Primary identification for filing MOHRE complaints.", howToGet: "ICP Smart App or physical card." }
        ],
        verifiedFacts: [
          "Wages delayed by more than 14 days trigger automatic company WPS restrictions from MOHRE.",
          "Claims under AED 100,000 are legally exempt from all court fees.",
          "Holding an employee's passport is strictly illegal under UAE Ministerial Circular No. 267 of 2002."
        ],
        practicalAdvice: [
          "Keep digital copies of all timesheets and salary records on your personal phone.",
          "Always file complaints within one year of the entitlement date."
        ],
        uncertainties: "Exact resolution timeline depends on whether the employer responds to MOHRE mediation.",
        disclaimer: "This guidance is educational support based on official UAE Labour Law and does not replace formal legal counsel."
      },
      ar: {
        summary: "دليل حقوق العمال في الإمارات: تأخر الأجور (نظام حماية الأجور WPS) وشكاوى وزارة الموارد البشرية والتوطين.",
        plainExplanation: "وفق المرسوم بقانون اتحادي رقم 33 لسنة 2021، يجب سداد الأجور في موعدها عبر نظام حماية الأجور (WPS). الدعاوى العمالية التي تقل قيمتها عن 100,000 درهم معفاة تماماً من الرسوم القضائية في كافة مراحل التقاضي.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "حفظ كشوف الرواتب وعقد العمل",
            description: "احفظ نسخة من عقد العمل الإلكتروني المعتمد من الوزارة، وكشف الحساب البنكي الذي يثبت تأخر الراتب.",
            urgency: "immediate",
            practicalTip: "احتجاز جواز السفر من قبل صاحب العمل محظور قانوناً تحت طائلة المساءلة."
          },
          {
            stepNumber: 2,
            title: "التواصل مع مراكز تواجه أو خط الوزارة المجاني",
            description: "اتصل بمركز اتصال وزارة الموارد البشرية والتوطين على 800-60 أو قم بزيارة مركز تواجه المعتمد للحصول على استشارة عمالية مجانية.",
            urgency: "next_step",
            practicalTip: "تقدم مراكز تواجه خدمات توعية وحلول ودية بأكثر من 15 لغة مجاناً."
          },
          {
            stepNumber: 3,
            title: "تسجيل شكوى عمالية رسمية",
            description: "قدّم الشكوى عبر تطبيق أو موقع الوزارة الرسمي (MOHRE). في حال تعذر الحل الودي خلال 14 يوماً، تحال الشكوى للمحكمة العمالية.",
            urgency: "official_filing",
            practicalTip: "المطالبات الأقل من 100 ألف درهم معفاة كلياً من كافة الرسوم القضائية."
          }
        ],
        requiredDocuments: [
          { name: "عقد العمل الإلكتروني المعتمد", whyNeeded: "لإثبات قيمة الأجر وتاريخ الاستحقاق والصفة الوظيفية.", howToGet: "تطبيق وزارة الموارد البشرية والتوطين (MOHRE App)." },
          { name: "كشف حساب بنكي / بطاقة الراتب", whyNeeded: "إثبات واقعة عدم إيداع الراتب عبر نظام WPS.", howToGet: "من البنك أو شركة الصرافة المعتمدة." },
          { name: "صورة بطاقة الهوية الإماراتية", whyNeeded: "لتسجيل الشكوى والتحقق من شخصية العامل.", howToGet: "تطبيق الهوية الرقمية أو البطاقة الأصلية." }
        ],
        verifiedFacts: [
          "تأخر الراتب لأكثر من 14 يوماً يفرض قيوداً إلكترونية تلقائية على منشأة العمل في نظام حماية الأجور.",
          "القضايا العمالية الأقل من 100,000 درهم معفاة من الرسوم القضائية في جميع مراحل التقاضي.",
          "حجز جواز سفر العامل ممنوع قانوناً بموجب التعميم الوزاري رقم 267 لسنة 2002 وقانون العقوبات."
        ],
        practicalAdvice: [
          "احتفظ دائماً بنسخة إلكترونية من عقد العمل وكشوف التحويل على هاتفك الشخصي.",
          "لا تتأخر في تقديم الشكوى العمالية، حيث تسقط المطالبات بمرور سنة من تاريخ الاستحقاق."
        ],
        uncertainties: "تعتمد مدة التسوية على استجابة صاحب العمل لجلسات التوفيق والتسوية بالوزارة.",
        disclaimer: "هذه المعلومات للتوعية بحقوق العمال وفق القانون الإماراتي ولا تعتبر استشارة قانونية رسمية."
      },
      ta: {
        summary: "அமீரக தொழிலாளர் உரிமைகள், சம்பள தாமதம் (WPS) மற்றும் MOHRE புகார் நடைமுறைகள்.",
        plainExplanation: "அமீரக தொழிலாளர் சட்டப்படி (சட்டம் எண் 33/2021) சம்பளத்தை WPS முறையில் குறிப்பிட்ட தேதியில் வழங்க வேண்டும். 100,000 திர்ஹத்திற்கு குறைவான தொழிலாளர் வழக்குகளுக்கு நீதிமன்ற கட்டணம் முற்றிலும் இலவசம்.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "சம்பள கணக்கு மற்றும் வேலை ஒப்பந்தத்தை சேகரிக்கவும்",
            description: "MOHRE தொழிலாளர் ஒப்பந்தம் மற்றும் வங்கி சம்பள பட்டியலை தயார் நிலையில் வைக்கவும்.",
            urgency: "immediate",
            practicalTip: "முதலாளி பாஸ்போர்ட்டை பறிமுதல் செய்ய சட்டத்தில் இடமில்லை; பாஸ்போர்ட் உங்கள் உரிமை."
          },
          {
            stepNumber: 2,
            title: "MOHRE உதவி எண் 800-60 அல்லது தவ்ஜீஹ் அணுகவும்",
            description: "இலவச ஆலோசனைக்கு MOHRE 800-60 எண்ணை அழைக்கவும் அல்லது தவ்ஜீஹ் (Tawjeeh) மையத்திற்கு செல்லவும்.",
            urgency: "next_step",
            practicalTip: "தவ்ஜீஹ் மையங்களில் தமிழில் ஆலோசனை பெறலாம்."
          },
          {
            stepNumber: 3,
            title: "MOHRE செயலியில் புகார் பதிவு செய்யவும்",
            description: "சம்பளம் வராத பட்சத்தில் MOHRE செயலியில் அதிகாரப்பூர்வ புகார் தாக்கல் செய்யவும்.",
            urgency: "official_filing",
            practicalTip: "1 லட்சம் திர்ஹத்திற்கு குறைவான வழக்குகளுக்கு நீதிமன்ற கட்டணம் கிடையாது."
          }
        ],
        requiredDocuments: [
          { name: "MOHRE வேலை ஒப்பந்தம்", whyNeeded: "சம்பளம் மற்றும் பணி விதிமுறைகளை நிரூபிக்க.", howToGet: "MOHRE செயலியில் பதிவிறக்கலாம்." },
          { name: "வங்கி சம்பள அறிக்கை (Bank Statement)", whyNeeded: "சம்பளம் வரவில்லை என்பதை நிரூபிக்க.", howToGet: "வங்கி அல்லது எக்ஸ்சேஞ்ச்." },
          { name: "எமிரேட்ஸ் ஐடி", whyNeeded: "புகார் பதிவு செய்ய.", howToGet: "அசல் அட்டை." }
        ],
        verifiedFacts: [
          "14 நாட்களுக்கு மேல் சம்பளம் தராவிட்டால் நிறுவனத்திற்கு MOHRE தடைகள் விதிக்கும்.",
          "1 லட்சம் திர்ஹத்திற்கு குறைவான தொழிலாளர் வழக்குகளுக்கு கட்டணம் இல்லை.",
          "தொழிலாளியின் பாஸ்போர்ட்டை பிடித்து வைப்பது சட்டவிரோதமானது."
        ],
        practicalAdvice: [
          "சம்பள விவரங்களை எப்போதும் போனில் பாதுகாப்பாக சேமித்து வைக்கவும்.",
          "சம்பள பாக்கி ஏற்பட்டு 1 வருடத்திற்குள் புகார் அளிக்க வேண்டும்."
        ],
        uncertainties: "நிறுவனம் சமரசத்திற்கு வரும் காலத்தை பொறுத்து தீர்வு கிடைக்கும்.",
        disclaimer: "இது விழிப்புணர்வு வழிகாட்டல் மட்டுமே; சட்ட ஆலோசகர் முடிவல்ல."
      },
      ml: {
        summary: "യുഎഇ തൊഴിലാളി അവകാശങ്ങൾ, ശമ്പള കുടിശ്ശിക (WPS), MOHRE പരാതി നടപടികൾ.",
        plainExplanation: "യുഎഇ ലേബർ നിയമപ്രകാരം (നിയമം 33/2021) ശമ്പളം കൃത്യസമയത്ത് WPS വഴി നൽകണം. ഒരു ലക്ഷം ദിർഹത്തിൽ താഴെയുള്ള ലേബർ കേസുകൾക്ക് കോടതി ഫീസ് പൂർണ്ണമായും സൗജന്യമാണ്.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "കരാറും ബാങ്ക് സ്റ്റേറ്റ്‌മെന്റും കരുതുക",
            description: "MOHRE തൊഴിൽ കരാറും ബാങ്ക് അക്കൗണ്ട് വിവരങ്ങളും രേഖയായി സൂക്ഷിക്കുക.",
            urgency: "immediate",
            practicalTip: "പാസ്‌പോർട്ട് കമ്പനി പിടിച്ചുവെക്കുന്നത് നിയമവിരുദ്ധമാണ്."
          },
          {
            stepNumber: 2,
            title: "MOHRE ടോൾ ഫ്രീ 800-60 അല്ലെങ്കിൽ തൗജീഹ് കേന്ദ്രത്തെ സമീപിക്കുക",
            description: "സൗജന്യ നിയമോപദേശത്തിന് MOHRE 800-60 വിളിക്കുകയോ തൗജീഹ് കേന്ദ്രത്തിൽ പോകുകയോ ചെയ്യുക.",
            urgency: "next_step",
            practicalTip: "മലയാളത്തിൽ ഉൾപ്പെടെ തൗജീഹിൽ സൗജന്യ മാർഗ്ഗനിർദ്ദേശം ലഭിക്കും."
          },
          {
            stepNumber: 3,
            title: "MOHRE ആപ്പിലൂടെ പരാതി നൽകുക",
            description: "തർക്കം രമ്യമായി തീർന്നില്ലെങ്കിൽ ഔദ്യോഗികമായി ലേബർ പരാതി ഫയൽ ചെയ്യുക.",
            urgency: "official_filing",
            practicalTip: "1 ലക്ഷം ദിർഹത്തിൽ താഴെയുള്ള ക്ലെയിമുകൾക്ക് കോടതി ഫീസ് ഇല്ല."
          }
        ],
        requiredDocuments: [
          { name: "ലേബർ കോൺട്രാക്ട്", whyNeeded: "ശമ്പള തുക തെളിയിക്കാൻ.", howToGet: "MOHRE ആപ്പിൽ നിന്ന് ലഭിക്കും." },
          { name: "ബാങ്ക് സ്റ്റേറ്റ്മെന്റ്", whyNeeded: "ശമ്പളം ലഭിച്ചില്ലെന്ന് തെളിയിക്കാൻ.", howToGet: "ബാങ്കിൽ നിന്ന്." },
          { name: "എമിറേറ്റ്സ് ഐഡി", whyNeeded: "പരാതി രജിസ്റ്റർ ചെയ്യാൻ.", howToGet: "ICP കാർഡ്." }
        ],
        verifiedFacts: [
          "14 ദിവസത്തിൽ കൂടുതൽ ശമ്പളം വൈകിയാൽ കമ്പനിക്ക് WPS നിയന്ത്രണം വരും.",
          "1 ലക്ഷം ദിർഹത്തിൽ താഴെയുള്ള കേസുകൾക്ക് കോടതി ഫീസ് സൗജന്യമാണ്.",
          "തൊഴിലാളിയുടെ പാസ്‌പോർട്ട് പിടിച്ചുവെക്കുന്നത് കർശനമായി നിരോധിച്ചിരിക്കുന്നു."
        ],
        practicalAdvice: [
          "ശമ്പള രേഖകൾ എപ്പോഴും ഫോണിൽ സൂക്ഷിക്കുക.",
          "ശമ്പള കുടിശ്ശിക വന്ന് ഒരു വർഷത്തിനുള്ളിൽ പരാതിപ്പെടണം."
        ],
        uncertainties: "കമ്പനി ചർച്ചകളോട് എങ്ങനെ പ്രതികരിക്കുന്നു എന്നതിനനുസരിച്ച് സമയമെടുക്കും.",
        disclaimer: "ഇത് വിവരങ്ങൾ നൽകുന്നതിനായുള്ള മാർഗ്ഗനിർദ്ദേശം മാത്രമാണ്."
      },
      hi: {
        summary: "यूएई श्रम अधिकार, वेतन में देरी (WPS) एवं MOHRE शिकायत प्रक्रिया।",
        plainExplanation: "यूएई श्रम कानून (डिक्री-लॉ 33/2021) के अनुसार वेतन समय पर WPS द्वारा दिया जाना अनिवार्य है। 1,00,000 दिरहम से कम के श्रम दावों पर कोर्ट फीस पूरी तरह माफ है।",
        actionSteps: [
          {
            stepNumber: 1,
            title: "श्रम अनुबंध एवं बैंक स्टेटमेंट सुरक्षित रखें",
            description: "MOHRE इलेक्ट्रॉनिक अनुबंध और बैंक खाता विवरण अपने पास रखें।",
            urgency: "immediate",
            practicalTip: "पासपोर्ट रखना गैरकानूनी है; यह कर्मचारी का अधिकार है।"
          },
          {
            stepNumber: 2,
            title: "MOHRE हेल्पलाइन 800-60 या तवजीह केंद्र से संपर्क करें",
            description: "मुफ्त सलाह के लिए MOHRE टोल-फ्री 800-60 पर कॉल करें या नजदीकी तवजीह केंद्र जाएं।",
            urgency: "next_step",
            practicalTip: "तवजीह केंद्रों पर हिंदी में भी मुफ्त मार्गदर्शन उपलब्ध है।"
          },
          {
            stepNumber: 3,
            title: "MOHRE ऐप पर आधिकारिक शिकायत दर्ज करें",
            description: "वेतन न मिलने पर MOHRE ऐप के माध्यम से औपचारिक शिकायत दर्ज करें।",
            urgency: "official_filing",
            practicalTip: "1 लाख दिरहम से कम के मामलों में कोई अदالती शुल्क नहीं लगता।"
          }
        ],
        requiredDocuments: [
          { name: "MOHRE श्रम अनुबंध", whyNeeded: "वेतन और शर्तों के प्रमाण हेतु।", howToGet: "MOHRE ऐप से डाउनलोड करें।" },
          { name: "बैंक खाता स्टेटमेंट", whyNeeded: "वेतन न आने के प्रमाण हेतु।", howToGet: "बैंक या एक्सचेंज से प्राप्त करें।" },
          { name: "एमिरेट्स आईडी कॉपी", whyNeeded: "शिकायत दर्ज करने हेतु।", howToGet: "ICP कार्ड।" }
        ],
        verifiedFacts: [
          "14 दिन से अधिक वेतन में देरी पर कंपनी पर स्वतः WPS पाबंदी लग जाती है।",
          "1,00,000 दिरहम से कम के श्रम विवादों में कोर्ट फीस पूरी तरह माफ है।",
          "कर्मचारी का पासपोर्ट रोकना यूएई कानून के तहत सख्त मना है।"
        ],
        practicalAdvice: [
          "अपने वेतन और उपस्थिति के प्रमाण हमेशा निजी फोन में रखें।",
          "वेतन बकाया होने के 1 वर्ष के भीतर शिकायत अवश्य करें।"
        ],
        uncertainties: "निवारण में लगने वाला समय कंपनी के सहयोग पर निर्भर करता है।",
        disclaimer: "यह सामान्य जानकारी है, कोई औपचारिक कानूनी सलाह नहीं।"
      },
      ur: {
        summary: "یو اے ای لیبر حقوق، تنخواہ میں تاخیر (WPS) اور MOHRE شکایات کا طریقہ کار۔",
        plainExplanation: "یو اے ای لیبر قانون (فرمان 33/2021) کے تحت تنخواہ مقررہ وقت پر WPS کے ذریعے ادا کرنا لازمی ہے۔ 1 لاکھ درہم سے کم کے لیبر مقدمات میں عدالتی فیس مکمل معاف ہے۔",
        actionSteps: [
          {
            stepNumber: 1,
            title: "لیبر کنٹریکٹ اور بینک ریکارڈ محفوظ کریں",
            description: "MOHRE کا لیبر کنٹریکٹ اور تنخواہ کا بینک اسٹیٹمنٹ اپنے پاس رکھیں۔",
            urgency: "immediate",
            practicalTip: "پاسپورٹ ضبط کرنا غیر قانونی ہے، پاسپورٹ واپس مانگیں۔"
          },
          {
            stepNumber: 2,
            title: "MOHRE ہیلپ لائن 800-60 یا توجیہ سینٹر سے رابطہ کریں",
            description: "مفت رہنمائی کے لیے MOHRE ہیلپ لائن 800-60 پر کال کریں یا توجیہ سینٹر جائیں۔",
            urgency: "next_step",
            practicalTip: "توجیہ سینٹرز میں اردو میں مفت رہنمائی فراہم کی جاتی ہے۔"
          },
          {
            stepNumber: 3,
            title: "MOHRE ایپ پر شکایت درج کروائیں",
            description: "مسئلہ حل نہ ہونے پر وزارت کی ایپ سے باضابطہ شکایت درج کروائیں۔",
            urgency: "official_filing",
            practicalTip: "ایک لاکھ درہم سے کم کے کلیم پر کوئی فیس نہیں لگتی۔"
          }
        ],
        requiredDocuments: [
          { name: "MOHRE لیبر کنٹریکٹ", whyNeeded: "تنخواہ اور شرائط کے ثبوت کے لیے۔", howToGet: "MOHRE ایپ سے ڈاؤن لوڈ کریں۔" },
          { name: "بینک اسٹیٹمنٹ", whyNeeded: "تنخواہ نہ ملنے کے ثبوت کے لیے۔", howToGet: "بینک یا ایکسچینج سے حاصل کریں۔" },
          { name: "اماراتی شناختی کارڈ", whyNeeded: "شکایت درج کرنے کے لیے۔", howToGet: "اصل کارڈ۔" }
        ],
        verifiedFacts: [
          "14 دن سے زیادہ تنخواہ لیٹ ہونے پر کمپنی پر WPS پابندی لگ جاتی ہے۔",
          "ایک لاکھ درہم سے کم کے لیبر کیسز میں تمام عدالتی فیس معاف ہے۔",
          "ملازم کا پاسپورٹ روکنا قانونی طور پر سخت منع ہے۔"
        ],
        practicalAdvice: [
          "تنخواہ کے تمام ثبوت اپنے ذاتی موبائل میں محفوظ رکھیں۔",
          "حقوق کی ادائیگی کے 1 سال کے اندر اندر شکایت درج کرائیں۔"
        ],
        uncertainties: "مسئلہ کے حل کا وقت کمپنی کے ردعمل پر منحصر ہے۔",
        disclaimer: "یہ صرف قانونی آگاہی ہے، کوئی حتمی عدالتی فیصلہ نہیں۔"
      }
    },
    everyday_uae: {
      en: {
        summary: "Guidance on everyday living, housing tenancy, healthcare, and emergencies in the UAE.",
        plainExplanation: "Everyday residency in the UAE involves mandatory Ejari (or Tawtheeq in Abu Dhabi) for tenancy, compulsory health insurance (DHA/DoH), and standardized emergency telephone numbers.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "Register tenancy on official portals (Ejari / Tawtheeq)",
            description: "Tenants in Dubai must register their lease on the Dubai Land Department Ejari system (Dubai REST app) to connect DEWA water and electricity.",
            urgency: "immediate",
            practicalTip: "Ensure your tenancy contract clearly lists maintenance responsibilities."
          },
          {
            stepNumber: 2,
            title: "Verify mandatory health insurance coverage",
            description: "Employers or sponsors must provide compliant health insurance under DHA (Dubai) or DoH (Abu Dhabi) regulations.",
            urgency: "next_step",
            practicalTip: "Download your insurance digital card and check participating clinic networks."
          },
          {
            stepNumber: 3,
            title: "Save UAE standardized emergency numbers",
            description: "Police: 999 | Ambulance: 998 | Fire: 997 | Non-emergency police & worker welfare: 901 | Electricity emergency: 991.",
            urgency: "official_filing",
            practicalTip: "Emergency calls to 999/998 are completely free from any mobile phone."
          }
        ],
        requiredDocuments: [
          { name: "Tenancy Contract & Title Deed", whyNeeded: "Required to register Ejari and connect utilities.", howToGet: "From landlord or leasing broker." },
          { name: "Emirates ID Copy", whyNeeded: "Universal identifier for Ejari, health insurance, and utility accounts.", howToGet: "ICP Smart app or physical card." },
          { name: "Health Insurance Card / Policy Number", whyNeeded: "To access clinic appointments and medical treatment.", howToGet: "Provided by employer or insurance company." }
        ],
        verifiedFacts: [
          "Ejari registration is legally mandatory in Dubai to connect DEWA utilities and sponsor family visas.",
          "Health insurance is legally mandatory for all visa holders in Dubai and Abu Dhabi.",
          "Emergency 999 (Police) and 998 (Ambulance) are accessible 24/7 toll-free nationwide."
        ],
        practicalAdvice: [
          "Keep digital copies of your Ejari certificate and insurance policy in cloud or phone storage.",
          "For non-emergency community issues, dial Dubai Police 901 instead of 999."
        ],
        uncertainties: "Tenancy rules and utility deposit requirements vary between individual Emirates.",
        disclaimer: "This guidance is provided for general informational purposes only and does not constitute official legal or government advice."
      },
      ar: {
        summary: "دليل الحياة اليومية في الإمارات: عقود إيجاري، الرعاية الصحية، وأرقام الطوارئ.",
        plainExplanation: "تشمل الإجراءات الأساسية للمعيشة في الإمارات توثيق عقود الإيجار السكنية عبر نظام إيجاري (أو توثيق في أبوظبي)، والتأمين الصحي الإلزامي المعتمد من هيئات الصحة، وحفظ أرقام الطوارئ الموحدة.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "توثيق عقد الإيجار (إيجاري / توثيق)",
            description: "يجب على المستأجرين في دبي تسجيل عقد الإيجار عبر نظام إيجاري بدائرة الأراضي والأملاك لتفعيل خدمات الكهرباء والمياه (ديوا). وفي أبوظبي يتم ذلك عبر توثيق.",
            urgency: "immediate",
            practicalTip: "تأكد من توضيح حدود مسؤولية الصيانة السنوية بدقة في العقد الإيجاري الموحد."
          },
          {
            stepNumber: 2,
            title: "التحقق من سريان التأمين الصحي الإلزامي",
            description: "يلزم القانون أصحاب العمل والكفلاء بتوفير تغطية تأمين صحي معتمدة وفق اشتراطات هيئة الصحة بدبي (DHA) أو دائرة الصحة بأبوظبي (DoH).",
            urgency: "next_step",
            practicalTip: "احفظ البطاقة الرقمية للتأمين الصحي وتحقق من شبكة المستشفيات والعيادات المشمولة."
          },
          {
            stepNumber: 3,
            title: "حفظ أرقام الطوارئ الرسمية الموحدة",
            description: "الشرطة للحالات الطارئة: 999 | الإسعاف: 998 | الدفاع المدني والحرائق: 997 | الشرطة لغير الطوارئ وخدمة الأمين: 901 | طوارئ الكهرباء والمياه: 991.",
            urgency: "official_filing",
            practicalTip: "المكالمات على أرقام الطوارئ 999 و998 مجانية تماماً من أي هاتف محمول."
          }
        ],
        requiredDocuments: [
          { name: "عقد الإيجار الموحد وشهادة الملكية", whyNeeded: "لتوثيق إيجاري وتوصيل خدمات الكهرباء والمياه.", howToGet: "من المالك أو الوسيط العقاري المرخص." },
          { name: "صورة بطاقة الهوية الإماراتية", whyNeeded: "المرجع التعريفي الموحد لجميع الخدمات الحكومية والصحية.", howToGet: "تطبيق الهوية الرقمية أو البطاقة الأصلية." },
          { name: "بطاقة التأمين الصحي / رقم الوثيقة", whyNeeded: "للحصول على العلاج في المراكز الطبية والعيادات.", howToGet: "من جهة العمل أو شركة التأمين." }
        ],
        verifiedFacts: [
          "تسجيل إيجاري إلزامي قانوناً في دبي لتوصيل خدمات ديوا وكفالة تأشيرات أفراد الأسرة.",
          "التأمين الصحي إلزامي قانوناً لجميع المقيمين في دبي وأبوظبي.",
          "أرقام الطوارئ 999 و998 متاحة على مدار 24 ساعة ومجانية على مستوى الدولة."
        ],
        practicalAdvice: [
          "احتفظ بنسخ إلكترونية من شهادة إيجاري ووثيقة التأمين على هاتفك أو السحابة الإلكترونية.",
          "للاستفسارات والخدمات غير الطارئة، اتصل على 901 بدلاً من 999."
        ],
        uncertainties: "تختلف رسوم الإيداع والتسجيل الإيجاري من إمارة لأخرى.",
        disclaimer: "هذه الإرشادات عامة ولا تغني عن الاستشارة القانونية أو مراجعة الجهة الحكومية المختصة."
      },
      ta: {
        summary: "அமீரகத்தில் அன்றாட வாழ்க்கை, எஜாரி வாடகை பதிவு, சுகாதாரம் மற்றும் அவசர உதவி.",
        plainExplanation: "துபாயில் வாடகை ஒப்பந்தத்தை எஜாரி (Ejari) முறையிலும், அபுதாபியில் தவதீக் (Tawtheeq) முறையிலும் பதிவு செய்ய வேண்டும். மருத்துவ காப்பீடு மற்றும் அவசர எண்கள் (999/998) மிக முக்கியமானவை.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "எஜாரி (Ejari) வாடகை பதிவு செய்யவும்",
            description: "DEWA மின்சாரம் & தண்ணீர் இணைப்பு பெற துபாய் லேண்ட் டிபார்ட்மென்ட் Ejari பதிவு கட்டாயம்.",
            urgency: "immediate",
            practicalTip: "ஒப்பந்தத்தில் பராமரிப்பு செலவு யார் ஏற்க வேண்டும் என்பதை தெளிவாக பார்க்கவும்."
          },
          {
            stepNumber: 2,
            title: "மருத்துவ காப்பீடு (Health Insurance) பெறவும்",
            description: "அமீரக சட்டப்படி ஒவ்வொரு விசா தாரருக்கும் மருத்துவ காப்பீடு கட்டாயம்.",
            urgency: "next_step",
            practicalTip: "உங்கள் இன்சூரன்ஸ் அட்டை செல்லும் மருத்துவமனைகளை முன்கூட்டியே அறியவும்."
          },
          {
            stepNumber: 3,
            title: "அவசர எண்களை போனில் சேமிக்கவும்",
            description: "காவல்துறை: 999 | ஆம்புலன்ஸ்: 998 | தீயணைப்பு: 997 | அவசரமல்லாத உதவி: 901.",
            urgency: "official_filing",
            practicalTip: "999 மற்றும் 998 அழைப்புகள் முற்றிலும் இலவசம்."
          }
        ],
        requiredDocuments: [
          { name: "வாடகை ஒப்பந்தம் (Tenancy Contract)", whyNeeded: "எஜாரி பதிவு செய்ய.", howToGet: "வீட்டு உரிமையாளரிடம் இருந்து." },
          { name: "எமிரேட்ஸ் ஐடி", whyNeeded: "அனைத்து அரசு சேவைகளுக்கும் அடையாளம்.", howToGet: "ICP அட்டை." },
          { name: "மருத்துவ காப்பீட்டு அட்டை", whyNeeded: "மருத்துவமனை சிகிச்சை பெற.", howToGet: "நிறுவனம் அல்லது காப்பீட்டு நிறுவனம்." }
        ],
        verifiedFacts: [
          "துபாயில் DEWA இணைப்பு மற்றும் குடும்ப விசா பெற எஜாரி கட்டாயம்.",
          "துபாய் மற்றும் அபுதாபியில் மருத்துவ காப்பீடு சட்டப்பூர்வமாக கட்டாயமாகும்.",
          "அவசர எண்கள் 999 மற்றும் 998 நாடெங்கிலும் 24 மணி நேரமும் இலவசமாக இயங்குகின்றன."
        ],
        practicalAdvice: [
          "எஜாரி ரசீது நகலை எப்போதும் போனில் வைத்திருக்கவும்.",
          "அவசரமில்லாத புகார்களுக்கு 999 அழைக்காமல் 901 அழைக்கவும்."
        ],
        uncertainties: "ஒவ்வொரு எமிரேட்டுக்கும் வாடகை விதிமுறைகள் மாறுபடலாம்.",
        disclaimer: "இது பொது வழிகாட்டல் மட்டுமே; அரசு முடிவல்ல."
      },
      ml: {
        summary: "യുഎഇ ദൈനംദിന ജീവിതം, ഇജാറി വാടക രജിസ്ട്രേഷൻ, ആരോഗ്യം, അടിയന്തര സേവനങ്ങൾ.",
        plainExplanation: "ദുബായിൽ വാടക കരാർ ഇജാറി (Ejari) വഴിയും അബുദാബിയിൽ തൗതീഖ് വഴിയും രജിസ്റ്റർ ചെയ്യണം. നിർബന്ധിത ആരോഗ്യ ഇൻഷുറൻസും അടിയന്തര നമ്പറുകളും (999/998) പ്രധാനമാണ്.",
        actionSteps: [
          {
            stepNumber: 1,
            title: "ഇജാറി രജിസ്ട്രേഷൻ പൂർത്തിയാക്കുക",
            description: "ദേവ (DEWA) വൈദ്യുതി കണക്ഷൻ ലഭിക്കാൻ ഇജാറി സർട്ടിഫിക്കറ്റ് നിർബന്ധമാണ്.",
            urgency: "immediate",
            practicalTip: "മെയിന്റനൻസ് വ്യവസ്ഥകൾ കരാറിൽ വ്യക്തമായി എഴുതിയിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക."
          },
          {
            stepNumber: 2,
            title: "ഹെൽത്ത് ഇൻഷുറൻസ് വിവരങ്ങൾ പരിശോധിക്കുക",
            description: "യുഎഇ നിയമപ്രകാരം എല്ലാ താമസക്കാർക്കും മെഡിക്കൽ ഇൻഷുറൻസ് നിർബന്ധമാണ്.",
            urgency: "next_step",
            practicalTip: "ഇൻഷുറൻസ് നെറ്റ്‌വർക്കിലുള്ള ക്ലിനിക്കുകൾ ഏതൊക്കെയാണെന്ന് അറിയുക."
          },
          {
            stepNumber: 3,
            title: "അടിയന്തര നമ്പറുകൾ സേവ് ചെയ്യുക",
            description: "പോലീസ്: 999 | ആംബുലൻസ്: 998 | ഫയർഫോഴ്സ്: 997 | നോൺ-എമർജൻസി: 901.",
            urgency: "official_filing",
            practicalTip: "999, 998 നമ്പറുകളിലേക്ക് വിളിക്കുന്നത് തികച്ചും സൗജന്യമാണ്."
          }
        ],
        requiredDocuments: [
          { name: "വാടക കരാർ", whyNeeded: "ഇജാറി രജിസ്റ്റർ ചെയ്യാൻ.", howToGet: "കെട്ടിട ഉടമയിൽ നിന്ന്." },
          { name: "എമിറേറ്റ്സ് ഐഡി", whyNeeded: "തിരിച്ചറിയൽ രേഖയായി.", howToGet: "ICP കാർഡ്." },
          { name: "ഇൻഷുറൻസ് കാർഡ്", whyNeeded: "ചികിത്സാ സഹായത്തിന്.", howToGet: "കമ്പനി നൽകുന്നത്." }
        ],
        verifiedFacts: [
          "ദുബായിൽ DEWA കണക്ഷന് ഇജാറി നിർബന്ധമാണ്.",
          "ദുബായിലും അബുദാബിയിലും ആരോഗ്യ ഇൻഷുറൻസ് നിർബന്ധമാണ്.",
          "അടിയന്തര നമ്പറുകൾ 24 മണിക്കൂറും പ്രവർത്തനക്ഷമമാണ്."
        ],
        practicalAdvice: [
          "ഇജാറി കോപ്പി ഫോണിൽ സൂക്ഷിക്കുക.",
          "അടിയന്തരമല്ലാത്ത കാര്യങ്ങൾക്ക് ദുബായ് പോലീസ് 901 വിളിക്കുക."
        ],
        uncertainties: "അതാത് എമിറേറ്റുകളിലെ വാടക നിയമങ്ങൾ വ്യത്യസ്തമായിരിക്കാം.",
        disclaimer: "ഇത് വിവരങ്ങൾ നൽകുന്നതിനായുള്ള മാർഗ്ഗനിർദ്ദേശം മാത്രമാണ്."
      },
      hi: {
        summary: "यूएई में दैनिक जीवन, आवास (एजारी), स्वास्थ्य सेवाएं एवं आपातकालीन नंबर।",
        plainExplanation: "दुबई में किराये के अनुबंध का पंजीकरण एजारी (Ejari) और आबू धाबी में तौसीक (Tawtheeq) के माध्यम से अनिवार्य है। स्वास्थ्य बीमा और आपातकालीन नंबर (999/998) अत्यंत महत्वपूर्ण हैं।",
        actionSteps: [
          {
            stepNumber: 1,
            title: "एजारी (Ejari) पर रेंट एग्रीमेंट दर्ज कराएं",
            description: "दुबई में DEWA बिजली-पानी कनेक्शन और वीजा के लिए एजारी प्रमाण पत्र अनिवार्य है।",
            urgency: "immediate",
            practicalTip: "एग्रीमेंट में मेंटेनेंस संबंधी शर्तों को ध्यान से पढ़ें।"
          },
          {
            stepNumber: 2,
            title: "अनिवार्य स्वास्थ्य बीमा की जांच करें",
            description: "यूएई कानून के अनुसार सभी वीजा धारकों के लिए मेडिकल बीमा होना जरूरी है।",
            urgency: "next_step",
            practicalTip: "अपने बीमा कार्ड में कवर होने वाले अस्पतालों की सूची देखें।"
          },
          {
            stepNumber: 3,
            title: "आपातकालीन नंबर सुरक्षित रखें",
            description: "पुलिस: 999 | एम्बुलेंस: 998 | फायर ब्रिगेड: 997 | गैर-आपातकालीन पुलिस: 901।",
            urgency: "official_filing",
            practicalTip: "999 और 998 पर कॉल पूरी तरह निःशुल्क है।"
          }
        ],
        requiredDocuments: [
          { name: "किराया अनुबंध (Tenancy Contract)", whyNeeded: "एजारी पंजीकरण हेतु।", howToGet: "मकान मालिक से प्राप्त करें।" },
          { name: "एमिरेट्स आईडी कॉपी", whyNeeded: "सरकारी सेवाओं के लिए।", howToGet: "ICP कार्ड।" },
          { name: "स्वास्थ्य बीमा कार्ड", whyNeeded: "इलाज के समय कवरेज हेतु।", howToGet: "नियोक्ता या बीमा कंपनी द्वारा।" }
        ],
        verifiedFacts: [
          "दुबई में DEWA कनेक्शन के लिए एजारी पंजीकरण कानूनी रूप से अनिवार्य है।",
          "स्वास्थ्य बीमा दुबई और आबू धाबी में कानूनी रूप से अनिवार्य है।",
          "आपातकालीन 999 और 998 नंबर 24 घंटे निःशुल्क उपलब्ध हैं।"
        ],
        practicalAdvice: [
          "एजारी और बीमा पॉलिसी की डिजिटल कॉपी फोन में रखें।",
          "गैर-आपातकालीन पूछताछ के लिए 999 की जगह 901 पर कॉल करें।"
        ],
        uncertainties: "अलग-अलग अमीरात में आवास के नियम थोड़े भिन्न हो सकते हैं।",
        disclaimer: "यह केवल सामान्य मार्गदर्शन है, कोई कानूनी सलाह नहीं।"
      },
      ur: {
        summary: "یو اے ای میں روزمرہ رہائش، ایجاری رینٹل، صحت کی سہولیات اور ایمرجنسی سروسز۔",
        plainExplanation: "دبئی میں کرایہ داری معاہدے کی رجسٹریشن ایجاری (Ejari) اور ابوظہبی میں توثیق کے تحت لازمی ہے۔ ہیلتھ انشورنس اور ایمرجنسی نمبرز (999/998) ضروری ہیں۔",
        actionSteps: [
          {
            stepNumber: 1,
            title: "ایجاری (Ejari) رجسٹریشن کروائیں",
            description: "DEWA پانی اور بجلی کے کنکشن کے لیے ایجاری کا ہونا لازمی ہے۔",
            urgency: "immediate",
            practicalTip: "معاہدے میں دیکھ بھال کے اخراجات کی شرائط واضح پڑھیں۔"
          },
          {
            stepNumber: 2,
            title: "ہیلتھ انشورنس چیک کریں",
            description: "یو اے ای قانون کے تحت تمام رہائشیوں کے لیے ہیلتھ انشورنس لازمی ہے۔",
            urgency: "next_step",
            practicalTip: "اپنے قریبی نیٹ ورک ہسپتالوں کی فہرست چیک کریں۔"
          },
          {
            stepNumber: 3,
            title: "ایمرجنسی نمبرز محفوظ رکھیں",
            description: "پولیس: 999 | ایمبولینس: 998 | فائر بریگیڈ: 997 | نان ایمرجنسی: 901۔",
            urgency: "official_filing",
            practicalTip: "999 اور 998 پر کال بالکل مفت ہے۔"
          }
        ],
        requiredDocuments: [
          { name: "رینٹل ایگریمنٹ", whyNeeded: "ایجاری کی تصدیق کے لیے۔", howToGet: "مالک مکان سے۔" },
          { name: "شناختی کارڈ کاپی", whyNeeded: "سرکاری ریکارڈ کے لیے۔", howToGet: "ICP کارڈ۔" },
          { name: "ہیلتھ انشورنس کارڈ", whyNeeded: "طبی علاج کے لیے۔", howToGet: "کمپنی کی طرف سے فراہم کردہ۔" }
        ],
        verifiedFacts: [
          "دبئی میں DEWA اور فیملی ویزا کے لیے ایجاری لازمی ہے۔",
          "ہیلتھ انشورنس قانوناً لازمی ہے۔",
          "ایمرجنسی نمبرز 999 اور 998 ملک بھر میں 24 گھنٹے مفت دستیاب ہیں۔"
        ],
        practicalAdvice: [
          "ایجاری کی کاپی موبائل میں محفوظ رکھیں۔",
          "عام معلومات کے لیے 999 کے بجائے 901 پر کال کریں۔"
        ],
        uncertainties: "مختلف امارات میں رینٹل قوانین میں کچھ فرق ہو سکتا ہے۔",
        disclaimer: "یہ صرف معلوماتی رہنمائی ہے۔"
      }
    }
  };

  const catTrans = responses[normalizedKey] || responses.everyday_uae;
  const langTrans = catTrans[language] || catTrans.en || responses.everyday_uae.en;
  return langTrans;
}
