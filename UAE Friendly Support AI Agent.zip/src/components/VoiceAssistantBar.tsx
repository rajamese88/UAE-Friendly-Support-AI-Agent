import { FC, useState, useEffect, useRef } from 'react';
import { SupportedLanguage } from '../types';
import { LANGUAGES, t } from '../data/translations';
import { Mic, MicOff, Send, AlertCircle, Loader2, Sparkles, X, Globe } from 'lucide-react';

interface VoiceAssistantBarProps {
  language: SupportedLanguage;
  isListening: boolean;
  isSupported: boolean;
  isTranscribing: boolean;
  errorMessage: string | null;
  onStartListening: () => void;
  onStopListening: () => void;
  onSubmitQuery: (query: string) => void;
  isLoadingGuidance: boolean;
  onClearError?: () => void;
  onOpenLanguageSelector?: () => void;
  liveTranscript?: string;
}

export const VoiceAssistantBar: FC<VoiceAssistantBarProps> = ({
  language,
  isListening,
  isSupported,
  isTranscribing,
  errorMessage,
  onStartListening,
  onStopListening,
  onSubmitQuery,
  isLoadingGuidance,
  onClearError,
  onOpenLanguageSelector,
  liveTranscript = '',
}) => {
  const [queryText, setQueryText] = useState('');
  const [hasInteractedWithSpeech, setHasInteractedWithSpeech] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const currentLangMeta = LANGUAGES.find((l) => l.code === language) || LANGUAGES[0];

  // Map language to BCP-47 tag string for visual indicator
  const bcp47Tags: Record<SupportedLanguage, string> = {
    ar: 'ar-AE',
    ta: 'ta-IN',
    ml: 'ml-IN',
    hi: 'hi-IN',
    ur: 'ur-PK',
    en: 'en-US',
  };

  // Sync live speech transcript to the editable input box so user can review and edit it
  useEffect(() => {
    if (liveTranscript) {
      setQueryText(liveTranscript);
      setHasInteractedWithSpeech(true);
    }
  }, [liveTranscript]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!queryText.trim() || isLoadingGuidance) return;
    if (isListening) {
      onStopListening();
    }
    onSubmitQuery(queryText.trim());
    setQueryText('');
    setHasInteractedWithSpeech(false);
  };

  const handleMicClick = () => {
    if (isListening) {
      onStopListening();
    } else {
      if (onClearError) {
        onClearError();
      }
      setHasInteractedWithSpeech(true);
      onStartListening();
    }
  };

  // Quick prompt presets covering all 4 modules in the selected language
  const promptChips: Record<SupportedLanguage, string[]> = {
    ar: [
      'تجديد الجوازات وإجراءات السفارات في الإمارات',
      'حافلات بين المدن من دبي إلى أبوظبي E100/E101 وبطاقة نول',
      'تأخر الراتب أكثر من 14 يوماً وفق نظام حماية الأجور (WPS)',
      'خطوات توثيق وتسجيل عقد إيجاري (Ejari)',
      'أرقام الطوارئ الرسمية في الإمارات (999/998/901)',
    ],
    en: [
      'Indian / Pak passport renewal at embassy',
      'Dubai to Abu Dhabi bus E100/E101 & Nol fare',
      'Salary delayed over 14 days under WPS',
      'How to register Ejari tenancy contract',
      'UAE emergency helplines (999/998/901)',
    ],
    ta: [
      'BLS இந்திய பாஸ்போர்ட் புதுப்பித்தல்',
      'துபாய் ↔ அபுதாபி பஸ் E101 & Nol கட்டணம்',
      'சம்பளம் 14 நாட்களுக்கு மேல் தாமதம்',
      'எஜாரி (Ejari) வாடகை பதிவு செய்வது எப்படி?',
      'அமீரக அவசர உதவி எண்கள் (999/998/901)',
    ],
    ml: [
      'പാസ്‌പോർട്ട് പുതുക്കൽ & BLS അപ്പോയിന്റ്മെന്റ്',
      'ദുബായ് ↔ അബുദാബി ബസ് E101 & നോൽ നിരക്ക്',
      'ശമ്പളം 14 ദിവസത്തിൽ കൂടുതൽ വൈകുന്നു',
      'ഇജാറി വാടക രജിസ്ട്രേഷൻ നടപടികൾ',
      'യുഎഇ അടിയന്തര നമ്പറുകൾ (999/998/901)',
    ],
    hi: [
      'भारतीय / पाकिस्तानी पासपोर्ट नवीनीकरण',
      'दुबई से आबू धाबी बस E101 व नोल कार्ड',
      'WPS के तहत वेतन 14 दिन से अधिक लेट',
      'एजारी (Ejari) रेंट एग्रीमेंट कैसे दर्ज करें?',
      'यूएई आपातकालीन नंबर (999/998/901)',
    ],
    ur: [
      'پاکستانی پاسپورٹ کی تجدید اور قونصل خانہ',
      'دبئی تا ابوظہبی بس E101 اور نول کرایہ',
      'تنخواہ میں 14 دن سے زیادہ تاخیر',
      'ایجاری کرایہ داری معاہدہ کی رجسٹریشن',
      'سرکاری ایمرجنسی نمبرز (999/998/901)',
    ],
  };

  const chips = promptChips[language] || promptChips.en;

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 space-y-3">
      {/* Top Header Row with Active Language Indicator */}
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 font-bold text-slate-800">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>{t('voiceInputTitle', language)}</span>
        </div>

        {onOpenLanguageSelector && (
          <button
            onClick={onOpenLanguageSelector}
            className="flex items-center gap-1 text-emerald-700 hover:text-emerald-800 font-semibold bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded-lg border border-emerald-200 transition-colors cursor-pointer"
            title="Change Speech & Guidance Language"
          >
            <Globe className="w-3 h-3" />
            <span>{currentLangMeta.nativeName}</span>
            <span className="text-[10px] text-emerald-600 font-mono">({bcp47Tags[language]})</span>
          </button>
        )}
      </div>

      {/* Main Chat Input Form with Microphone Button BESIDE the Input */}
      <form onSubmit={handleSubmit} className="relative">
        <div className={`flex items-center gap-2 p-1.5 rounded-2xl border-2 transition-all bg-slate-50 ${
          isListening
            ? 'border-rose-500 ring-4 ring-rose-100 bg-rose-50/30'
            : 'border-slate-300 focus-within:border-emerald-600 focus-within:ring-3 focus-within:ring-emerald-100'
        }`}>
          {/* Text Input (Editable, shows spoken transcript for review before sending) */}
          <input
            ref={inputRef}
            type="text"
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder={
              isListening
                ? `Listening in ${currentLangMeta.name} (${bcp47Tags[language]})... Speak now`
                : t('typeInstead', language)
            }
            disabled={isLoadingGuidance}
            className="flex-1 bg-transparent px-3 py-2 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 outline-hidden"
          />

          {/* Clear button if text is entered */}
          {queryText && (
            <button
              type="button"
              onClick={() => {
                setQueryText('');
                setHasInteractedWithSpeech(false);
              }}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-full cursor-pointer"
              title="Clear input"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          {/* MICROPHONE BUTTON (Placed directly beside the chat input) */}
          <button
            type="button"
            onClick={handleMicClick}
            disabled={isLoadingGuidance || isTranscribing}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all cursor-pointer shrink-0 shadow-xs ${
              isListening
                ? 'bg-rose-600 hover:bg-rose-700 text-white animate-pulse scale-105'
                : isTranscribing
                ? 'bg-amber-500 text-white'
                : isSupported
                ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-300'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
            title={
              !isSupported
                ? 'Microphone not supported on this browser'
                : isListening
                ? 'Stop recording and review text'
                : `Tap to speak in ${currentLangMeta.name} (${bcp47Tags[language]})`
            }
            aria-label={isListening ? 'Stop microphone' : 'Start microphone'}
          >
            {isTranscribing ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : isListening ? (
              <MicOff className="w-5 h-5 text-white" />
            ) : (
              <Mic className="w-5 h-5 text-emerald-800" />
            )}
          </button>

          {/* SEND BUTTON (Beside mic, sends reviewed text to AI Chat) */}
          <button
            type="submit"
            disabled={!queryText.trim() || isLoadingGuidance}
            className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed text-white h-10 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-transform active:scale-95 cursor-pointer shrink-0"
            title="Send reviewed question to AI Chat"
          >
            {isLoadingGuidance ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <span>{t('askAssistant', language)}</span>
                <Send className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </form>

      {/* Real-time Listening Active Banner with Review Prompt */}
      {isListening && (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-2.5 flex items-center justify-between text-xs text-rose-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-600"></span>
            </span>
            <span>
              <strong>{t('listeningNow', language)}</strong> — Your speech appears above for you to review or edit before sending.
            </span>
          </div>
          <button
            onClick={onStopListening}
            className="bg-rose-600 text-white font-bold px-2 py-0.5 rounded text-[11px] hover:bg-rose-700 cursor-pointer"
          >
            {t('stopListening', language)}
          </button>
        </div>
      )}

      {/* Review & Edit Reminder after Speech is Recognized */}
      {!isListening && hasInteractedWithSpeech && queryText.trim() && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-1.5 flex items-center justify-between text-[11px] text-emerald-800">
          <span>✓ Speech converted to text. You can edit the text in the box above, or click <strong>"{t('askAssistant', language)}"</strong>.</span>
        </div>
      )}

      {/* Friendly error / unsupported notice if speech recognition fails or is not available */}
      {(!isSupported || errorMessage) && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex items-start justify-between gap-2 animate-in fade-in">
          <div className="flex items-start gap-2 flex-1">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold">
                {errorMessage || t('micNotSupported', language)}
              </p>
              <p className="mt-0.5 text-slate-600 text-[11px]">
                Text chat remains fully available above. You can also use the microphone button on your phone keyboard.
              </p>
              {isSupported && errorMessage && (
                <button
                  type="button"
                  onClick={handleMicClick}
                  className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 hover:text-emerald-950 bg-emerald-100 hover:bg-emerald-200 px-2.5 py-1 rounded-lg border border-emerald-300 transition-colors cursor-pointer"
                >
                  <Mic className="w-3 h-3" />
                  <span>Tap to retry speaking</span>
                </button>
              )}
            </div>
          </div>
          {onClearError && errorMessage && (
            <button
              onClick={onClearError}
              className="text-amber-700 hover:text-amber-900 p-1 cursor-pointer shrink-0"
              title="Dismiss notice"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Quick Suggestion Chips to help workers ask common questions easily */}
      <div className="pt-1">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider shrink-0">
            Quick Ask:
          </span>
          {chips.map((chip, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setQueryText(chip);
                if (inputRef.current) {
                  inputRef.current.focus();
                }
              }}
              className="bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 text-[11px] px-2.5 py-1 rounded-lg border border-slate-200 whitespace-nowrap transition-colors cursor-pointer shrink-0"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
