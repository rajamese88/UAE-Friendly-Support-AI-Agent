import { FC } from 'react';
import { Smartphone, Mic, CheckCircle, Volume2, ShieldCheck, X, Server, Bell, KeyRound } from 'lucide-react';

interface AndroidGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidGuideModal: FC<AndroidGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="bg-emerald-900 text-white p-4.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold">
              Android Phone Setup & Testing Guide
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-800 hover:bg-emerald-700 flex items-center justify-center text-emerald-200 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 flex items-start gap-2.5">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>
              This application is designed specifically for budget Android smartphones (such as Samsung Galaxy A-series, Redmi, Vivo, Realme, and Infinix) running Google Chrome.
            </span>
          </div>

          {/* Step 1: Open in Chrome */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-1.5">
            <h4 className="font-bold text-slate-900 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">1</span>
              <span>Open in Google Chrome</span>
            </h4>
            <p className="text-slate-600">
              For best speech recognition in Arabic, English, Tamil, Malayalam, Hindi, and Urdu, open the app link inside Google Chrome on Android rather than in-app webviews like WhatsApp browser.
            </p>
          </div>

          {/* Step 2: Allow Microphone Access */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-1.5">
            <h4 className="font-bold text-slate-900 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">2</span>
              <span>Allow Microphone Permissions</span>
            </h4>
            <p className="text-slate-600">
              When you tap the big green <strong>Speak</strong> button, Chrome will ask: <em>"Allow this site to use your microphone?"</em> Tap <strong>"While using the app"</strong>.
            </p>
            <div className="bg-slate-50 p-2 rounded-lg text-slate-500 text-[11px] flex items-center gap-1.5">
              <Mic className="w-3.5 h-3.5 text-slate-400" />
              <span>If blocked by mistake: Tap the Lock icon in Chrome address bar &gt; Site settings &gt; Microphone &gt; Allow.</span>
            </div>
          </div>

          {/* Step 3: Test Voice Audio Readout */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-1.5">
            <h4 className="font-bold text-slate-900 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">3</span>
              <span>Testing Voice Readout & Sound</span>
            </h4>
            <p className="text-slate-600">
              Tap the <strong>Volume speaker button</strong> on any action step or language preview. Make sure your phone's media volume is turned up. The app uses server-side Gemini audio with automatic local Android speech fallback.
            </p>
            <div className="bg-slate-50 p-2 rounded-lg text-slate-500 text-[11px] flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-slate-400" />
              <span>Works even in noisy labour accommodations when earphones are connected.</span>
            </div>
          </div>

          {/* Step 4: Add to Home Screen (1-Tap Icon) */}
          <div className="border border-slate-200 rounded-xl p-3.5 space-y-1.5">
            <h4 className="font-bold text-slate-900 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">4</span>
              <span>Add to Android Home Screen</span>
            </h4>
            <p className="text-slate-600">
              Tap the <strong>three dots (⋮)</strong> at the top right of Chrome &gt; select <strong>"Add to Home screen"</strong> or <strong>"Install app"</strong>. The companion will now appear directly on your phone home screen like a native app.
            </p>
          </div>

          {/* Integration Roadmap for Production */}
          <div className="bg-slate-900 text-white rounded-xl p-4 space-y-3">
            <h4 className="font-bold text-amber-400 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Server className="w-4 h-4" />
              <span>Production Integration Roadmap</span>
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              To expand this prototype into a full-scale UAE public welfare service, the following technical integrations are recommended:
            </p>

            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2">
                <KeyRound className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Live Official Government Feeds:</strong>
                  <span className="text-slate-300 block">Integration with MOHRE Open Data API and Dubai Courts case status inquiry portal.</span>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Mic className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Gemini Live Real-Time Voice:</strong>
                  <span className="text-slate-300 block">Bi-directional WebSocket streaming audio for real-time natural dialogue in low-bandwidth networks.</span>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Secure Cloud Storage (Firebase):</strong>
                  <span className="text-slate-300 block">Tokenized anonymous user storage for syncing checklists across devices without collecting personal IDs.</span>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Bell className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">WhatsApp & SMS Reminder Webhooks:</strong>
                  <span className="text-slate-300 block">Official WhatsApp Business Cloud API to send workers reminder notifications for their 14-day salary dispute deadlines.</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-xs cursor-pointer"
          >
            Got it, return to Companion
          </button>
        </div>
      </div>
    </div>
  );
};
