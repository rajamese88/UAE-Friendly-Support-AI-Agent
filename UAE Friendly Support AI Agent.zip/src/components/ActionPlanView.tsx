import { FC, useState } from 'react';
import { GuidanceResult, SupportedLanguage } from '../types';
import { t } from '../data/translations';
import {
  Volume2,
  SquareCheckBig,
  ShieldCheck,
  FileCheck2,
  ExternalLink,
  PhoneCall,
  CalendarCheck,
  PlusCircle,
  HelpCircle,
  Info,
  Check,
  CheckCircle2,
  Circle,
  RotateCcw,
} from 'lucide-react';

interface ActionPlanViewProps {
  plan: GuidanceResult;
  language: SupportedLanguage;
  onPlayAudio: (id: string, text: string) => void;
  isPlayingAudio: boolean;
  activeAudioId: string | null;
  onAddStepsToTracker: (steps: GuidanceResult['actionSteps']) => void;
  hasAddedToTracker: boolean;
  onResetPlan: () => void;
}

export const ActionPlanView: FC<ActionPlanViewProps> = ({
  plan,
  language,
  onPlayAudio,
  isPlayingAudio,
  activeAudioId,
  onAddStepsToTracker,
  hasAddedToTracker,
  onResetPlan,
}) => {
  // Local state for interactive step completion toggling right on the plan
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const toggleStepCompleted = (stepNumber: number) => {
    setCompletedSteps((prev) =>
      prev.includes(stepNumber)
        ? prev.filter((n) => n !== stepNumber)
        : [...prev, stepNumber]
    );
  };

  const fullPlanAudioText = `${plan.summary}. ${plan.plainExplanation}. ${plan.actionSteps
    .map((s) => `Step ${s.stepNumber}: ${s.title}. ${s.description}`)
    .join('. ')}`;

  const isFullPlanPlaying = isPlayingAudio && activeAudioId === 'full_plan';
  const completedCount = completedSteps.length;
  const totalCount = plan.actionSteps.length;
  const progressPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* Top action header card */}
      <div className="bg-gradient-to-br from-emerald-900 to-emerald-950 text-white rounded-2xl p-5 shadow-md">
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              {t('actionPlanTitle', language)}
            </span>
          </div>

          {/* SPEAKER BUTTON to read AI response aloud */}
          <button
            onClick={() => onPlayAudio('full_plan', fullPlanAudioText)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
              isFullPlanPlaying
                ? 'bg-amber-500 text-emerald-950 scale-105 shadow-md animate-pulse ring-2 ring-amber-300'
                : 'bg-emerald-800 hover:bg-emerald-700 text-emerald-100 border border-emerald-600/60'
            }`}
            title="Read complete response aloud in your selected language"
            aria-label="Read response aloud"
          >
            <Volume2 className="w-4 h-4" />
            <span>{isFullPlanPlaying ? t('stopAudio', language) : t('readAloud', language)}</span>
          </button>
        </div>

        <h2 className="text-lg sm:text-xl font-bold leading-snug text-white">
          {plan.summary}
        </h2>
        <p className="mt-2 text-xs sm:text-sm text-emerald-100/90 leading-relaxed bg-emerald-800/40 p-3 rounded-xl border border-emerald-700/50">
          {plan.plainExplanation}
        </p>

        {/* Action button row */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-emerald-800/80">
          <button
            onClick={() => onAddStepsToTracker(plan.actionSteps)}
            disabled={hasAddedToTracker}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              hasAddedToTracker
                ? 'bg-emerald-700/70 text-emerald-200 cursor-default'
                : 'bg-amber-400 hover:bg-amber-300 active:scale-95 text-emerald-950 shadow-sm'
            }`}
          >
            {hasAddedToTracker ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>{t('stepsAddedToast', language)}</span>
              </>
            ) : (
              <>
                <PlusCircle className="w-4 h-4" />
                <span>{t('addToTrackerBtn', language)}</span>
              </>
            )}
          </button>

          <button
            onClick={onResetPlan}
            className="flex items-center gap-1 text-xs text-emerald-300 hover:text-white underline cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Ask another question</span>
          </button>
        </div>
      </div>

      {/* Numbered Action Steps with Interactive Checkboxes (Pending vs Completed) */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <SquareCheckBig className="w-5 h-5 text-emerald-600" />
            <h3 className="text-base font-bold text-slate-900">
              Step-by-Step Action Checklist
            </h3>
          </div>
          <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
            {completedCount}/{totalCount} Completed ({progressPercent}%)
          </span>
        </div>

        {/* Visual Progress Bar */}
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
          <div
            className="bg-emerald-600 h-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>

        {/* Step Items List */}
        <div className="space-y-3 pt-1">
          {plan.actionSteps.map((step) => {
            const stepId = `step_${step.stepNumber}`;
            const isStepAudioPlaying = isPlayingAudio && activeAudioId === stepId;
            const isCompleted = completedSteps.includes(step.stepNumber);
            const stepAudioText = `Step ${step.stepNumber}: ${step.title}. ${step.description}. Tip: ${step.practicalTip}`;

            const urgencyBadges: Record<string, { label: string; bg: string }> = {
              immediate: { label: 'Immediate Action', bg: 'bg-rose-100 text-rose-800 border-rose-200' },
              next_step: { label: 'Next Practical Step', bg: 'bg-amber-100 text-amber-800 border-amber-200' },
              official_filing: { label: 'Official Resolution', bg: 'bg-blue-100 text-blue-800 border-blue-200' },
            };

            const badge = urgencyBadges[step.urgency] || urgencyBadges.next_step;

            return (
              <div
                key={step.stepNumber}
                className={`p-3.5 rounded-xl border transition-all ${
                  isCompleted
                    ? 'border-emerald-300 bg-emerald-50/50'
                    : 'border-slate-200 bg-slate-50/60 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-start gap-2.5 flex-1">
                    {/* Interactive Checkbox toggle (Pending vs Completed) */}
                    <button
                      type="button"
                      onClick={() => toggleStepCompleted(step.stepNumber)}
                      className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all cursor-pointer shrink-0 mt-0.5 shadow-xs ${
                        isCompleted
                          ? 'bg-emerald-600 text-white'
                          : 'border-2 border-slate-300 bg-white hover:border-emerald-500 text-transparent'
                      }`}
                      title={isCompleted ? 'Mark step as pending' : 'Mark step as completed'}
                      aria-label={`Toggle completion for step ${step.stepNumber}`}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-300" />
                      )}
                    </button>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${badge.bg}`}>
                          {badge.label}
                        </span>

                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                            isCompleted
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {isCompleted ? '✓ Completed' : 'Pending'}
                        </span>
                      </div>

                      <h4
                        className={`text-sm font-bold ${
                          isCompleted ? 'text-emerald-900 line-through opacity-80' : 'text-slate-900'
                        }`}
                      >
                        Step {step.stepNumber}: {step.title}
                      </h4>
                    </div>
                  </div>

                  {/* Speaker Button to read this individual step aloud */}
                  <button
                    onClick={() => onPlayAudio(stepId, stepAudioText)}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                      isStepAudioPlaying
                        ? 'bg-amber-500 text-slate-950 scale-105 shadow-md animate-pulse'
                        : 'bg-slate-200 hover:bg-slate-300 text-slate-700'
                    }`}
                    title="Read this step aloud"
                    aria-label={`Read step ${step.stepNumber} aloud`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>

                <p className="mt-2 text-xs sm:text-sm text-slate-700 leading-relaxed pl-9.5">
                  {step.description}
                </p>

                {step.practicalTip && (
                  <div className="mt-2 ml-9.5 p-2 bg-amber-50/80 rounded-lg border border-amber-200/60 text-xs text-amber-900 flex items-start gap-2">
                    <Info className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span>
                      <strong className="font-semibold">Helpful Tip: </strong>
                      {step.practicalTip}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Distinction: Verified UAE Legal Rules vs Practical Safety Tips */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
        {/* Verified UAE Legal Facts */}
        <div className="bg-emerald-50/80 border-2 border-emerald-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-2 mb-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-900">
              {t('verifiedRulesBadge', language)}
            </h4>
          </div>
          <ul className="space-y-2 text-xs text-emerald-950 leading-relaxed">
            {plan.verifiedFacts.map((fact, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-emerald-600 font-bold mt-0.5">•</span>
                <span>{fact}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Practical Safety Tips */}
        <div className="bg-amber-50/80 border-2 border-amber-200 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center gap-2 mb-2.5">
            <Info className="w-4 h-4 text-amber-700" />
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-900">
              {t('practicalAdviceBadge', language)}
            </h4>
          </div>
          <ul className="space-y-2 text-xs text-amber-950 leading-relaxed">
            {plan.practicalAdvice.map((advice, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-amber-600 font-bold mt-0.5">•</span>
                <span>{advice}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Relevant Documents Checklist based on official guidance */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <FileCheck2 className="w-4 h-4 text-emerald-600" />
            <span>{t('requiredDocsTitle', language)}</span>
          </h3>
          <span className="text-[11px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium">
            Self-help records
          </span>
        </div>

        <div className="space-y-2.5">
          {plan.requiredDocuments.map((doc, idx) => (
            <div key={idx} className="p-3 rounded-xl border border-slate-200 bg-slate-50/50 text-xs">
              <div className="font-bold text-slate-900 flex items-center justify-between">
                <span>{doc.name}</span>
              </div>
              <p className="text-slate-600 mt-1">
                <strong className="text-slate-700">Why needed: </strong>
                {doc.whyNeeded}
              </p>
              <p className="text-emerald-800 font-medium mt-1">
                <strong>How to get without company permission: </strong>
                {doc.howToGet}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Uncertainty and Jurisdiction notice */}
      {plan.uncertainties && (
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-700 flex items-start gap-2.5">
          <HelpCircle className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-slate-900 block mb-0.5">
              Jurisdiction & Process Note:
            </span>
            <span>{plan.uncertainties}</span>
          </div>
        </div>
      )}

      {/* Official Sources & Verification Timestamp */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs space-y-2.5">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <CalendarCheck className="w-4 h-4 text-emerald-600" />
            <h4 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">
              {t('officialSourcesTitle', language)}
            </h4>
          </div>
          <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded text-[10px] font-bold">
            Verified {plan.verifiedDate}
          </span>
        </div>

        <div className="space-y-1.5 pt-1">
          {plan.sources && plan.sources.map((src, i) => (
            <div key={i} className="flex items-center justify-between text-slate-600">
              <span className="font-medium truncate max-w-[240px] sm:max-w-none">{src.name}</span>
              <a
                href={src.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1 shrink-0 ml-2"
              >
                <span>Visit Source</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          ))}
        </div>

        {/* Immediate Call Helpline */}
        <div className="mt-3 pt-3 border-t border-slate-200 flex items-center justify-between">
          <span className="text-slate-600">MOHRE Official 24/7 Helpline:</span>
          <a
            href="tel:80060"
            className="bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 shadow-xs"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call 800-60 Free</span>
          </a>
        </div>
      </div>
    </div>
  );
};
