import { FC } from 'react';
import { SupportedLanguage } from '../types';
import { t } from '../data/translations';
import { ShieldCheck, AlertTriangle, Lock, EyeOff, UserCheck, X } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: SupportedLanguage;
}

export const PrivacyModal: FC<PrivacyModalProps> = ({ isOpen, onClose, language }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold">
              Privacy, Safety & Legal Limitations
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
          {/* Independence Disclaimer */}
          <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-amber-950 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-amber-900">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Independent Guidance Assistant</span>
            </div>
            <p className="text-xs text-amber-900 leading-relaxed">
              {t('disclaimerNotice', language)}
            </p>
          </div>

          {/* Core Commitments */}
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-xl border border-slate-100 bg-slate-50">
              <EyeOff className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-slate-900">Zero Sensitive ID Collection</h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  We never request or store your Emirates ID number, passport number, visa UID, banking PIN, or passwords.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-xl border border-slate-100 bg-slate-50">
              <Lock className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-slate-900">Local Device Storage</h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  Your action plan and follow-up checklists reside entirely inside your browser's private storage on this device. No documents are uploaded to our servers.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3 rounded-xl border border-slate-100 bg-slate-50">
              <UserCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-bold text-slate-900">No Automated External Actions</h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  This assistant will never contact your employer, message your sponsor, or file a complaint without your explicit human action. You retain 100% control.
                </p>
              </div>
            </div>
          </div>

          {/* Authentic Citations */}
          <div className="bg-slate-100 p-3.5 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1.5">
            <h4 className="font-bold text-slate-800">Legal Reference Basis:</h4>
            <p>
              All factual rules are verified against <strong>UAE Federal Decree-Law No. 33 of 2021</strong> on the Regulation of Labour Relations and official MOHRE Ministerial Decisions.
            </p>
            <p className="text-[11px] text-slate-500">
              For binding legal arbitration or official dispute filings, always refer directly to MOHRE (800-60) or licensed Tawjeeh guidance centres.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-xs cursor-pointer"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
