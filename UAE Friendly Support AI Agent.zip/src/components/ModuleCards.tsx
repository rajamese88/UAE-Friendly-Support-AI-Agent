import { FC } from 'react';
import { ScenarioType, SupportedLanguage } from '../types';
import { t } from '../data/translations';
import {
  FileText,
  Bus,
  Scale,
  Building2,
  Volume2,
  ArrowRight,
} from 'lucide-react';

interface ModuleCardsProps {
  language: SupportedLanguage;
  onSelectModule: (module: ScenarioType) => void;
  onPlayAudio: (id: string, text: string) => void;
  isPlayingAudio: boolean;
  activeAudioId: string | null;
}

export const ModuleCards: FC<ModuleCardsProps> = ({
  language,
  onSelectModule,
  onPlayAudio,
  isPlayingAudio,
  activeAudioId,
}) => {
  const modules = [
    {
      id: 'passport_visa' as ScenarioType,
      icon: FileText,
      badgeBg: 'bg-indigo-100 text-indigo-900 border-indigo-200',
      cardBorder: 'hover:border-indigo-400',
      iconBg: 'bg-indigo-50 text-indigo-700',
      title: t('modulePassportVisaTitle', language),
      description: t('modulePassportVisaDesc', language),
      tag: 'ICP / GDRFA / BLS / NADRA',
      audioText: `${t('modulePassportVisaTitle', language)}. ${t('modulePassportVisaDesc', language)}`,
    },
    {
      id: 'transport_travel' as ScenarioType,
      icon: Bus,
      badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-200',
      cardBorder: 'hover:border-emerald-400',
      iconBg: 'bg-emerald-50 text-emerald-700',
      title: t('moduleTransportTitle', language),
      description: t('moduleTransportDesc', language),
      tag: 'RTA Metro / Nol / S\'hail / Darbi',
      audioText: `${t('moduleTransportTitle', language)}. ${t('moduleTransportDesc', language)}`,
    },
    {
      id: 'worker_support' as ScenarioType,
      icon: Scale,
      badgeBg: 'bg-amber-100 text-amber-900 border-amber-200',
      cardBorder: 'hover:border-amber-400',
      iconBg: 'bg-amber-50 text-amber-700',
      title: t('moduleWorkerTitle', language),
      description: t('moduleWorkerDesc', language),
      tag: 'MOHRE 800-60 / WPS / Tawjeeh',
      audioText: `${t('moduleWorkerTitle', language)}. ${t('moduleWorkerDesc', language)}`,
    },
    {
      id: 'everyday_uae' as ScenarioType,
      icon: Building2,
      badgeBg: 'bg-sky-100 text-sky-900 border-sky-200',
      cardBorder: 'hover:border-sky-400',
      iconBg: 'bg-sky-50 text-sky-700',
      title: t('moduleEverydayTitle', language),
      description: t('moduleEverydayDesc', language),
      tag: 'Ejari / DHA Health / 999 Emergency',
      audioText: `${t('moduleEverydayTitle', language)}. ${t('moduleEverydayDesc', language)}`,
    },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm sm:text-base font-bold text-slate-900">
          {t('modulesTitle', language)}
        </h2>
        <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
          4 Official Modules
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {modules.map((mod) => {
          const Icon = mod.icon;
          const isThisPlaying = isPlayingAudio && activeAudioId === mod.id;

          return (
            <div
              key={mod.id}
              onClick={() => onSelectModule(mod.id)}
              className={`bg-white rounded-2xl p-4 border-2 border-slate-200 ${mod.cardBorder} shadow-xs hover:shadow-md transition-all cursor-pointer relative group flex flex-col justify-between`}
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-11 h-11 rounded-xl ${mod.iconBg} flex items-center justify-center transition-colors shrink-0`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border mb-1 ${mod.badgeBg}`}>
                        {mod.tag}
                      </span>
                      <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                        {mod.title}
                      </h3>
                    </div>
                  </div>

                  {/* Audio button for literacy and auditory accessibility */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlayAudio(mod.id, mod.audioText);
                    }}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                      isThisPlaying
                        ? 'bg-amber-500 text-slate-950 scale-105 shadow-md animate-pulse'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                    title={t('readAloud', language)}
                    aria-label={`Listen to ${mod.title}`}
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="mt-2.5 text-xs text-slate-600 leading-relaxed">
                  {mod.description}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-emerald-700 group-hover:text-emerald-800">
                <span>{t('askAssistant', language)}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
