import { FC, useState } from 'react';
import { ScenarioType, SupportedLanguage } from '../types';
import { SCENARIO_QUESTIONS } from '../data/scenarioQuestions';
import { ShieldCheck, ArrowRight, ArrowLeft, X, Sparkles, Loader2 } from 'lucide-react';

interface QuestionFlowModalProps {
  isOpen: boolean;
  onClose: () => void;
  scenario: ScenarioType;
  language: SupportedLanguage;
  onSubmit: (answers: Record<string, string>) => void;
  isLoading: boolean;
}

export const QuestionFlowModal: FC<QuestionFlowModalProps> = ({
  isOpen,
  onClose,
  scenario,
  language,
  onSubmit,
  isLoading,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});

  if (!isOpen) return null;

  const questions = SCENARIO_QUESTIONS[scenario] || [];
  const currentQuestion = questions[currentStepIndex];

  const handleSelectOption = (optionValue: string) => {
    const updated = { ...answers, [currentQuestion.id]: optionValue };
    setAnswers(updated);

    if (currentStepIndex < questions.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    } else {
      onSubmit(updated);
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  const handleSkipToPlan = () => {
    onSubmit(answers);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-emerald-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-700 flex items-center justify-center text-xs font-bold text-amber-300">
              {currentStepIndex + 1}/{questions.length}
            </span>
            <span className="text-sm font-bold uppercase tracking-wider text-emerald-200">
              Quick Practical Questions
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-800 hover:bg-emerald-700 flex items-center justify-center text-emerald-200 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sensitive data protection reassurance notice */}
        <div className="bg-emerald-50 px-4 py-2 border-b border-emerald-100 flex items-center gap-2 text-xs text-emerald-900">
          <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
          <span className="font-semibold">
            We never ask for Emirates ID, passport number, or passwords.
          </span>
        </div>

        {/* Question content */}
        <div className="p-5 overflow-y-auto flex-1">
          {currentQuestion && (
            <div className="space-y-4">
              <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                {currentQuestion.question[language] || currentQuestion.question.en}
              </h3>

              <div className="space-y-2.5">
                {currentQuestion.options.map((option) => {
                  const isSelected = answers[currentQuestion.id] === option.value;
                  return (
                    <button
                      key={option.value}
                      onClick={() => handleSelectOption(option.value)}
                      disabled={isLoading}
                      className={`w-full text-left p-3.5 rounded-xl border-2 transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50/80 text-emerald-950 font-bold shadow-xs'
                          : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <span className="text-sm">
                        {option.label[language] || option.label.en}
                      </span>
                      <ArrowRight className="w-4 h-4 text-slate-400 shrink-0 ml-2" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          {currentStepIndex > 0 ? (
            <button
              onClick={handlePrev}
              disabled={isLoading}
              className="px-3.5 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
          ) : (
            <button
              onClick={handleSkipToPlan}
              disabled={isLoading}
              className="text-xs text-slate-500 hover:text-slate-700 underline font-medium cursor-pointer"
            >
              Skip questions & generate plan
            </button>
          )}

          <button
            onClick={() => onSubmit(answers)}
            disabled={isLoading}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shadow-xs transition-transform active:scale-95 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Creating Plan...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Generate Plan</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
