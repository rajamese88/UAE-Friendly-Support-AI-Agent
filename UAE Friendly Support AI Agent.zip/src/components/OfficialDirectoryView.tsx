import { FC, useState } from 'react';
import { SupportedLanguage } from '../types';
import { OFFICIAL_SERVICES } from '../data/officialServices';
import { t } from '../data/translations';
import { Phone, ExternalLink, ShieldCheck, Clock, Languages, Search, AlertCircle } from 'lucide-react';

interface OfficialDirectoryViewProps {
  language: SupportedLanguage;
}

export const OfficialDirectoryView: FC<OfficialDirectoryViewProps> = ({ language }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    { id: 'all', label: 'All Services' },
    { id: 'transport', label: '🚇 Transport & Metro' },
    { id: 'embassy', label: '🛂 Passports & Embassies' },
    { id: 'government', label: '🏛️ Visas & Labour' },
    { id: 'housing_health', label: '🏥 Housing & Health' },
    { id: 'emergency', label: '🚨 24/7 Emergency' },
  ];

  const filteredServices = OFFICIAL_SERVICES.filter((svc) => {
    const matchesCat = selectedCategory === 'all' || svc.category === selectedCategory;
    const matchesSearch =
      svc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      svc.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (svc.arabicName && svc.arabicName.includes(searchQuery));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* Directory intro banner */}
      <div className="bg-emerald-900 text-white p-4.5 rounded-2xl shadow-sm space-y-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-amber-400" />
          <h2 className="text-base font-bold">
            Verified Official UAE Support Services
          </h2>
        </div>
        <p className="text-xs text-emerald-100 leading-relaxed">
          All contacts below are verified official UAE government departments, licensed Tawjeeh guidance centres, and diplomatic welfare helplines. No invented numbers or fake fees.
        </p>
        <div className="pt-2 border-t border-emerald-800 flex items-center gap-2 text-[11px] text-amber-300 font-medium">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>Note: Claims under AED 100,000 are 100% exempt from court fees under UAE law.</span>
        </div>
      </div>

      {/* Search and category filter */}
      <div className="space-y-2.5">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, issue, or language..."
            className="w-full bg-white border border-slate-200 rounded-xl pl-9.5 pr-4 py-2 text-xs sm:text-sm text-slate-900 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 outline-hidden"
          />
        </div>

        {/* Categories scrollable pill row */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Services List */}
      <div className="space-y-3">
        {filteredServices.length === 0 ? (
          <div className="bg-white p-6 rounded-2xl text-center text-slate-500 text-xs border border-slate-200">
            No services found matching your search.
          </div>
        ) : (
          filteredServices.map((svc) => (
            <div
              key={svc.id}
              className="bg-white rounded-2xl p-4.5 border border-slate-200 hover:border-emerald-400 shadow-xs transition-all space-y-3"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 leading-snug">
                    {svc.name}
                  </h3>
                  {svc.arabicName && (
                    <p className="text-xs text-slate-500 font-medium mt-0.5" dir="rtl">
                      {svc.arabicName}
                    </p>
                  )}
                </div>

                <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0">
                  {svc.category.replace('_', ' ')}
                </span>
              </div>

              <p className="text-xs text-slate-600 leading-relaxed">
                {svc.description}
              </p>

              <div className="space-y-1.5 text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{svc.operatingHours}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Languages className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="truncate">
                    Languages: {svc.languages.join(', ')}
                  </span>
                </div>
              </div>

              {/* Action buttons: Call and Visit */}
              <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
                <a
                  href={`tel:${(svc.tollFree || svc.phone).replace(/[^0-9+]/g, '')}`}
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-transform"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{t('callNow', language)}: {svc.tollFree || svc.phone}</span>
                </a>

                {svc.website && (
                  <a
                    href={svc.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>{t('visitWebsite', language)}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
