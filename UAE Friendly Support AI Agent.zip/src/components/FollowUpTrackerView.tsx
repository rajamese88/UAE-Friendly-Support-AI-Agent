import { FC, useState } from 'react';
import { FollowUpItem, FollowUpStatus, SupportedLanguage } from '../types';
import {
  CheckCircle2,
  Clock,
  HelpCircle,
  Plus,
  Trash2,
  HardDrive,
  Sparkles,
} from 'lucide-react';

interface FollowUpTrackerViewProps {
  items: FollowUpItem[];
  language: SupportedLanguage;
  onUpdateStatus: (id: string, status: FollowUpStatus) => void;
  onAddItem: (title: string, description: string) => void;
  onDeleteItem: (id: string) => void;
  onLoadDemoData: (type: 'salary' | 'passport') => void;
  onClearAll: () => void;
}

export const FollowUpTrackerView: FC<FollowUpTrackerViewProps> = ({
  items,
  onUpdateStatus,
  onAddItem,
  onDeleteItem,
  onLoadDemoData,
  onClearAll,
}) => {
  const [filter, setFilter] = useState<'all' | FollowUpStatus>('all');
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const statusConfig: Record<
    FollowUpStatus,
    { label: string; bg: string; text: string; border: string; icon: any }
  > = {
    pending: {
      label: 'Pending',
      bg: 'bg-slate-100',
      text: 'text-slate-700',
      border: 'border-slate-300',
      icon: Clock,
    },
    in_progress: {
      label: 'In Progress',
      bg: 'bg-amber-100',
      text: 'text-amber-800',
      border: 'border-amber-300',
      icon: Clock,
    },
    completed: {
      label: 'Completed',
      bg: 'bg-emerald-100',
      text: 'text-emerald-800',
      border: 'border-emerald-300',
      icon: CheckCircle2,
    },
    needs_help: {
      label: 'Needs Assistance',
      bg: 'bg-rose-100',
      text: 'text-rose-800',
      border: 'border-rose-300',
      icon: HelpCircle,
    },
  };

  const filteredItems = items.filter((item) => {
    if (filter === 'all') return true;
    return item.status === filter;
  });

  const handleCreateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onAddItem(newTitle.trim(), newDesc.trim());
    setNewTitle('');
    setNewDesc('');
    setShowAddForm(false);
  };

  const cycleStatus = (current: FollowUpStatus): FollowUpStatus => {
    switch (current) {
      case 'pending': return 'in_progress';
      case 'in_progress': return 'completed';
      case 'completed': return 'needs_help';
      case 'needs_help': return 'pending';
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-300">
      {/* Header banner */}
      <div className="bg-emerald-900 text-white p-4.5 rounded-2xl shadow-sm space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-amber-400" />
            <span>My Personal Follow-Up Tracker</span>
          </h2>
          <span className="text-xs bg-emerald-800 px-2.5 py-0.5 rounded-full font-bold">
            {items.filter((i) => i.status === 'completed').length}/{items.length} Done
          </span>
        </div>
        <p className="text-xs text-emerald-100 leading-relaxed">
          Keep track of each practical step you take. Tap any step status tag to cycle through Pending, In Progress, Completed, or Needs Help.
        </p>

        {/* Local Storage & No SMS notice */}
        <div className="pt-2 border-t border-emerald-800 flex items-center justify-between text-[11px] text-emerald-200">
          <span className="flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-amber-300" />
            <span>Saved securely on this phone only</span>
          </span>
          <span className="text-slate-300 text-[10px]">No sensitive docs stored</span>
        </div>
      </div>

      {/* Demo loader & actions row */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onLoadDemoData('salary')}
            className="text-xs font-bold bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 px-3 py-1.5 rounded-xl flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Load Salary Demo</span>
          </button>
          <button
            onClick={() => onLoadDemoData('passport')}
            className="text-xs font-bold bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-300 px-3 py-1.5 rounded-xl flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Load Passport Demo</span>
          </button>
        </div>

        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition-transform active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Custom Step</span>
        </button>
      </div>

      {/* Add Custom Step Form */}
      {showAddForm && (
        <form
          onSubmit={handleCreateItem}
          className="bg-white p-4 rounded-2xl border-2 border-emerald-500 shadow-sm space-y-3 animate-in slide-in-from-top-2"
        >
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Create Custom Action Step
          </h4>
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Step title (e.g., Requested bank statement from ATM)"
            required
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:border-emerald-500 outline-hidden"
          />
          <textarea
            value={newDesc}
            onChange={(e) => setNewDesc(e.target.value)}
            placeholder="Details or notes (e.g. Visited branch at 10 AM, officer told me to return tomorrow)"
            rows={2}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-slate-900 focus:border-emerald-500 outline-hidden"
          />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-1.5 rounded-xl text-xs font-bold shadow-xs cursor-pointer"
            >
              Save Step
            </button>
          </div>
        </form>
      )}

      {/* Status Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {(['all', 'pending', 'in_progress', 'completed', 'needs_help'] as const).map((st) => (
          <button
            key={st}
            onClick={() => setFilter(st)}
            className={`px-3 py-1 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
              filter === st
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {st === 'all'
              ? `All (${items.length})`
              : `${statusConfig[st].label} (${items.filter((i) => i.status === st).length})`}
          </button>
        ))}
      </div>

      {/* Checklist items */}
      <div className="space-y-2.5">
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-2xl p-6 text-center text-xs text-slate-500 border border-slate-200 space-y-2">
            <p>No action steps in this list yet.</p>
            <p className="text-slate-400">
              Generate an action plan above or tap "Load Demo" to see how it works!
            </p>
          </div>
        ) : (
          filteredItems.map((item) => {
            const currentConfig = statusConfig[item.status];
            const StatusIcon = currentConfig.icon;

            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-3.5 border border-slate-200 shadow-xs hover:border-slate-300 transition-all flex items-start justify-between gap-3"
              >
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      onClick={() => onUpdateStatus(item.id, cycleStatus(item.status))}
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border flex items-center gap-1 cursor-pointer transition-transform active:scale-95 ${currentConfig.bg} ${currentConfig.text} ${currentConfig.border}`}
                      title="Tap to change status"
                    >
                      <StatusIcon className="w-3 h-3" />
                      <span>{currentConfig.label}</span>
                    </button>
                    <span className="text-[10px] text-slate-400">
                      {item.createdAt}
                    </span>
                  </div>

                  <h3 className={`text-sm font-bold text-slate-900 ${item.status === 'completed' ? 'line-through text-slate-400' : ''}`}>
                    {item.title}
                  </h3>

                  {item.description && (
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.description}
                    </p>
                  )}
                </div>

                <button
                  onClick={() => onDeleteItem(item.id)}
                  className="text-slate-300 hover:text-rose-600 p-1 rounded-lg transition-colors cursor-pointer shrink-0"
                  title="Delete step"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* Clear all option */}
      {items.length > 0 && (
        <div className="pt-2 flex justify-between items-center text-xs text-slate-400">
          <span>Reminder: No automated SMS reminders are sent. Bookmark this page on your phone.</span>
          <button
            onClick={onClearAll}
            className="text-rose-600 hover:underline cursor-pointer font-medium ml-2 shrink-0"
          >
            Clear Checklist
          </button>
        </div>
      )}
    </div>
  );
};
