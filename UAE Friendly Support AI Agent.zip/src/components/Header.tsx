import { FC } from 'react';
import { SupportedLanguage } from '../types';
import { LANGUAGES, t } from '../data/translations';
import { Globe, PhoneCall, ShieldAlert } from 'lucide-react';

interface HeaderProps {
  language: SupportedLanguage;
  onOpenLanguageModal: () => void;
  onOpenPrivacyModal: () => void;
}

export const Header: FC<HeaderProps> = ({
  language,
  onOpenLanguageModal,
  onOpenPrivacyModal,
}) => {
  const currentLang = LANGUAGES.find((l) => l.code === language) || LANGUAGES[0];

  return (
    <header className="sticky top-0 z-30 bg-emerald-900 text-white shadow-md">
      {/* Top emergency & independence bar */}
      <div className="bg-emerald-950 px-3 py-1.5 flex items-center justify-between text-xs border-b border-emerald-800">
        <button
          onClick={onOpenPrivacyModal}
          className="flex items-center gap-1.5 text-emerald-200 hover:text-white transition-colors cursor-pointer"
        >
          <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="font-medium truncate max-w-[210px] sm:max-w-none">
            {t('disclaimerBadge', language)}
          </span>
        </button>

        <a
          href="tel:80060"
          className="flex items-center gap-1 bg-amber-500 hover:bg-amber-400 text-emerald-950 font-bold px-2 py-0.5 rounded text-[11px] shadow-xs shrink-0 transition-transform active:scale-95"
          title="MOHRE Official Toll Free Helpline"
        >
          <PhoneCall className="w-3 h-3" />
          <span>MOHRE 800-60</span>
        </a>
      </div>

      {/* Main navigation header */}
      <div className="max-w-3xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-md text-emerald-950 font-black text-lg shrink-0">
            ⚖️
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold leading-tight tracking-tight">
              {t('appTitle', language)}
            </h1>
            <p className="text-[11px] text-emerald-200 leading-tight hidden xs:block">
              {t('appTagline', language)}
            </p>
          </div>
        </div>

        {/* Language selector button */}
        <button
          onClick={onOpenLanguageModal}
          className="flex items-center gap-1.5 bg-emerald-800/80 hover:bg-emerald-700/80 active:bg-emerald-700 px-3 py-1.5 rounded-lg border border-emerald-600/60 shadow-xs text-xs font-semibold cursor-pointer transition-all"
        >
          <Globe className="w-4 h-4 text-emerald-300" />
          <span className="text-sm">{currentLang.flag}</span>
          <span className="font-bold">{currentLang.nativeName}</span>
        </button>
      </div>
    </header>
  );
};
