import { FC } from 'react';
import { SupportedLanguage } from '../types';
import { LANGUAGES, t } from '../data/translations';
import { Check, Volume2, X } from 'lucide-react';

interface LanguageSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  onPlayPreview: (lang: SupportedLanguage, text: string) => void;
  isPlayingPreview: boolean;
  activePreviewLang: string | null;
}

export const LanguageSelectorModal: FC<LanguageSelectorModalProps> = ({
  isOpen,
  onClose,
  currentLanguage,
  onSelectLanguage,
  onPlayPreview,
  isPlayingPreview,
  activePreviewLang,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl overflow-hidden border border-slate-200">
        <div className="bg-emerald-900 text-white px-5 py-4 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold">
              {t('selectLanguage', currentLanguage)}
            </h3>
            <p className="text-xs text-emerald-200 mt-0.5">
              Choose your language for voice and text guidance
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-emerald-800 hover:bg-emerald-700 flex items-center justify-center text-emerald-200 hover:text-white transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-2.5 max-h-[70vh] overflow-y-auto">
          {LANGUAGES.map((lang) => {
            const isSelected = currentLanguage === lang.code;
            const isPlayingThis = isPlayingPreview && activePreviewLang === lang.code;

            return (
              <div
                key={lang.code}
                className={`flex items-center justify-between p-3.5 rounded-xl border-2 transition-all cursor-pointer ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/70 shadow-xs'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                }`}
                onClick={() => {
                  onSelectLanguage(lang.code);
                  onClose();
                }}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl" role="img" aria-label={lang.name}>
                    {lang.flag}
                  </span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-bold text-slate-900">
                        {lang.nativeName}
                      </span>
                      {lang.nativeName !== lang.name && (
                        <span className="text-xs text-slate-500 font-medium">
                          ({lang.name})
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-500">
                      {lang.code === 'ar'
                        ? 'العربية (من اليمين إلى اليسار)'
                        : lang.code === 'ur'
                        ? 'اردو رسم الخط (دائیں سے بائیں)'
                        : 'Voice & Text Support'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  {/* Voice sample button */}
                  <button
                    onClick={() => onPlayPreview(lang.code, lang.sampleVoiceText)}
                    className={`w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                      isPlayingThis
                        ? 'bg-amber-500 text-emerald-950 scale-105 shadow-md animate-pulse'
                        : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                    }`}
                    title="Listen to voice preview"
                    aria-label={`Listen to preview in ${lang.name}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  {/* Selected checkmark indicator */}
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      isSelected
                        ? 'bg-emerald-600 text-white'
                        : 'border border-slate-300'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 text-center">
          <p className="text-xs text-slate-600">
            Arabic, English, Tamil, Malayalam, Hindi, & Urdu supported for voice and text guidance.
          </p>
        </div>
      </div>
    </div>
  );
};
