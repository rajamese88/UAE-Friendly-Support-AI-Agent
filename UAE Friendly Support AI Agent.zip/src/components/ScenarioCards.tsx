import { FC } from 'react';
import { ScenarioType, SupportedLanguage } from '../types';
import { t } from '../data/translations';
import { Banknote, FileText, Landmark, Volume2, ArrowRight } from 'lucide-react';

interface ScenarioCardsProps {
  language: SupportedLanguage;
  onSelectScenario: (scenario: ScenarioType) => void;
  onPlayAudio: (id: string, text: string) => void;
  isPlayingAudio: boolean;
  activeAudioId: string | null;
}

export const ScenarioCards: FC<ScenarioCardsProps> = ({
  language,
  onSelectScenario,
  onPlayAudio,
  isPlayingAudio,
  activeAudioId,
}) => {
  const cards = [
    {
      type: 'delayed_salary' as ScenarioType,
      icon: Banknote,
      color: 'amber',
      badgeBg: 'bg-amber-100 text-amber-900 border-amber-200',
      cardBorder: 'hover:border-amber-400',
      title: t('scenarioSalaryTitle', language),
      description: t('scenarioSalaryDesc', language),
      audioText: `${t('scenarioSalaryTitle', language)}. ${t('scenarioSalaryDesc', language)}`,
      tag: 'WPS Protection / 14 Days Rule',
    },
    {
      type: 'contract_issue' as ScenarioType,
      icon: FileText,
      color: 'emerald',
      badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-200',
      cardBorder: 'hover:border-emerald-400',
      title: t('scenarioDocsTitle', language),
      description: t('scenarioDocsDesc', language),
      audioText: `${t('scenarioDocsTitle', language)}. ${t('scenarioDocsDesc', language)}`,
      tag: 'Passport Rights / MOHRE Contract',
    },
    {
      type: 'official_service' as ScenarioType,
      icon: Landmark,
      color: 'blue',
      badgeBg: 'bg-blue-100 text-blue-900 border-blue-200',
      cardBorder: 'hover:border-blue-400',
      title: t('scenarioServicesTitle', language),
      description: t('scenarioServicesDesc', language),
      audioText: `${t('scenarioServicesTitle', language)}. ${t('scenarioServicesDesc', language)}`,
      tag: 'MOHRE 800-60 / Tawjeeh / Court',
    },
  ];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-base font-bold text-slate-900">
          {t('threeScenariosTitle', language)}
        </h2>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {cards.map((card) => {
          const Icon = card.icon;
          const isThisPlaying = isPlayingAudio && activeAudioId === card.type;

          return (
            <div
              key={card.type}
              onClick={() => onSelectScenario(card.type)}
              className={`bg-white rounded-2xl p-4 border-2 border-slate-200 ${card.cardBorder} shadow-xs hover:shadow-md transition-all cursor-pointer relative group flex flex-col justify-between`}
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-slate-100 group-hover:bg-emerald-50 text-slate-700 group-hover:text-emerald-700 flex items-center justify-center transition-colors shrink-0">
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border mb-1 ${card.badgeBg}`}>
                        {card.tag}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 leading-snug">
                        {card.title}
                      </h3>
                    </div>
                  </div>

                  {/* Audio button for literacy support */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlayAudio(card.type, card.audioText);
                    }}
                    className={`w-9 h-9 rounded-full flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                      isThisPlaying
                        ? 'bg-amber-500 text-slate-950 scale-105 shadow-md animate-pulse'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                    title={t('readAloud', language)}
                    aria-label={`Listen to ${card.title}`}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>

                <p className="mt-2.5 text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {card.description}
                </p>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-emerald-700 group-hover:text-emerald-800">
                <span>{t('askAssistant', language)}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
