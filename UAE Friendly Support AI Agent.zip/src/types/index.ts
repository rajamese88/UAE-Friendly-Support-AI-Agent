export type SupportedLanguage = 'ta' | 'ml' | 'hi' | 'ur' | 'en' | 'ar';

export type ModuleType = 'passport_visa' | 'transport_travel' | 'worker_support' | 'everyday_uae';

export type ScenarioType =
  | 'passport_visa'
  | 'transport_travel'
  | 'worker_support'
  | 'everyday_uae'
  | 'delayed_salary'
  | 'contract_issue'
  | 'official_service';

export type StepUrgency = 'immediate' | 'next_step' | 'official_filing';

export type FollowUpStatus = 'pending' | 'in_progress' | 'completed' | 'needs_help';

export interface ActionStep {
  stepNumber: number;
  title: string;
  description: string;
  urgency: StepUrgency;
  practicalTip: string;
}

export interface RequiredDocument {
  name: string;
  whyNeeded: string;
  howToGet: string;
}

export interface OfficialSource {
  name: string;
  url: string;
  verifiedDate: string;
}

export interface GuidanceResult {
  summary: string;
  plainExplanation: string;
  actionSteps: ActionStep[];
  requiredDocuments: RequiredDocument[];
  verifiedFacts: string[];
  practicalAdvice: string[];
  uncertainties: string;
  disclaimer: string;
  sources: OfficialSource[];
  verifiedDate: string;
  source: string;
  module?: ScenarioType;
}

export interface OfficialService {
  id: string;
  name: string;
  arabicName?: string;
  category: 'government' | 'guidance_centre' | 'judicial' | 'embassy' | 'emergency' | 'transport' | 'housing_health';
  phone: string;
  tollFree?: string;
  website: string;
  operatingHours: string;
  languages: string[];
  description: string;
  verifiedDate: string;
  isMainlandOnly?: boolean;
}

export interface FollowUpItem {
  id: string;
  title: string;
  description: string;
  status: FollowUpStatus;
  scenario?: ScenarioType;
  dueDate?: string;
  createdAt: string;
  notes?: string;
}

export interface QuestionOption {
  value: string;
  label: Record<SupportedLanguage, string>;
}

export interface ScenarioQuestion {
  id: string;
  question: Record<SupportedLanguage, string>;
  options: QuestionOption[];
}
