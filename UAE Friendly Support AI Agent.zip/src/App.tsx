/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import {
  SupportedLanguage,
  ScenarioType,
  GuidanceResult,
  FollowUpItem,
  FollowUpStatus,
} from './types';
import { Header } from './components/Header';
import { LanguageSelectorModal } from './components/LanguageSelectorModal';
import { VoiceAssistantBar } from './components/VoiceAssistantBar';
import { ModuleCards } from './components/ModuleCards';
import { QuestionFlowModal } from './components/QuestionFlowModal';
import { ActionPlanView } from './components/ActionPlanView';
import { OfficialDirectoryView } from './components/OfficialDirectoryView';
import { FollowUpTrackerView } from './components/FollowUpTrackerView';
import { AndroidGuideModal } from './components/AndroidGuideModal';
import { PrivacyModal } from './components/PrivacyModal';
import { useVoiceRecognition } from './hooks/useVoiceRecognition';
import { useAudioPlayer } from './hooks/useAudioPlayer';
import { t } from './data/translations';
import { VERIFIED_KNOWLEDGE, getFallbackGuidance } from './data/verifiedKnowledge';
import {
  MessageSquare,
  Landmark,
  CheckSquare,
  Smartphone,
  Loader2,
  Sparkles,
  User,
  RotateCcw,
} from 'lucide-react';

const STORAGE_KEY_ITEMS = 'uae_life_tracker_items';
const STORAGE_KEY_LANG = 'uae_life_lang';

export default function App() {
  // Application State
  const [language, setLanguage] = useState<SupportedLanguage>('en');
  const [activeTab, setActiveTab] = useState<'assistant' | 'directory' | 'tracker' | 'guide'>('assistant');
  const [activeModule, setActiveModule] = useState<ScenarioType | null>(null);
  const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [isPrivacyModalOpen, setIsPrivacyModalOpen] = useState(false);
  const [isAndroidGuideModalOpen, setIsAndroidGuideModalOpen] = useState(false);

  // Guidance plan state & conversational query history
  const [currentPlan, setCurrentPlan] = useState<GuidanceResult | null>(null);
  const [lastUserQuery, setLastUserQuery] = useState<string | null>(null);
  const [isLoadingGuidance, setIsLoadingGuidance] = useState(false);
  const [hasAddedToTracker, setHasAddedToTracker] = useState(false);
  const [guidanceNotice, setGuidanceNotice] = useState<string | null>(null);

  // Live transcribed speech text for review before sending
  const [liveTranscript, setLiveTranscript] = useState<string>('');

  // Follow-up tracker items in local state
  const [trackerItems, setTrackerItems] = useState<FollowUpItem[]>([]);

  // Load saved language and checklist items on mount
  useEffect(() => {
    try {
      const savedLang = (localStorage.getItem(STORAGE_KEY_LANG) || localStorage.getItem('uae_worker_lang')) as SupportedLanguage | null;
      if (savedLang && ['ar', 'ta', 'ml', 'hi', 'ur', 'en'].includes(savedLang)) {
        setLanguage(savedLang);
      }

      const savedItems = localStorage.getItem(STORAGE_KEY_ITEMS) || localStorage.getItem('uae_worker_tracker_items');
      if (savedItems) {
        setTrackerItems(JSON.parse(savedItems));
      } else {
        // Preload sample items to immediately demonstrate tracker capability
        setTrackerItems(getInitialDemoItems('salary'));
      }
    } catch (err) {
      console.warn('LocalStorage load error:', err);
    }
  }, []);

  // Save checklist items to localStorage
  const saveTrackerItems = (items: FollowUpItem[]) => {
    setTrackerItems(items);
    try {
      localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(items));
    } catch (err) {
      console.warn('LocalStorage save error:', err);
    }
  };

  const handleSelectLanguage = (newLang: SupportedLanguage) => {
    setLanguage(newLang);
    try {
      localStorage.setItem(STORAGE_KEY_LANG, newLang);
    } catch {
      // ignore
    }
  };

  // Audio player hook (Gemini TTS + Web Speech synthesis fallback with voice matching)
  const audioPlayer = useAudioPlayer();

  // Voice recognition hook (Populates liveTranscript for review & edit before sending)
  const voiceRecognition = useVoiceRecognition({
    language,
    onTranscript: (recognizedText) => {
      // Convert recognized speech into text and let the user review/edit it before sending
      setLiveTranscript(recognizedText);
    },
    onError: (err) => {
      console.warn('Voice recognition notice:', err);
    },
  });

  // Fetch or generate Action Plan with resilient fallback
  const fetchGuidancePlan = async (
    moduleKey: ScenarioType,
    details?: Record<string, string>,
    customQuery?: string
  ) => {
    setIsLoadingGuidance(true);
    setHasAddedToTracker(false);
    setGuidanceNotice(null);
    if (customQuery) {
      setLastUserQuery(customQuery);
    }

    try {
      const response = await fetch('/api/guidance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          module: moduleKey,
          scenario: moduleKey,
          language,
          details,
          customQuery,
        }),
      });

      let json: any = null;
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        json = await response.json();
      } else {
        const text = await response.text();
        console.warn(`[API Notice] Non-JSON response from /api/guidance (HTTP ${response.status}):`, text.slice(0, 150));
        throw new Error(`Endpoint returned HTTP ${response.status} (${response.statusText || 'Non-JSON'})`);
      }

      if (response.ok && json?.success && json?.data) {
        setCurrentPlan(json.data);
        if (json.data.aiNotice) {
          setGuidanceNotice(json.data.aiNotice);
        }
      } else {
        throw new Error(json?.error || `HTTP ${response.status}: Failed to generate response`);
      }
    } catch (err: any) {
      console.warn('API guidance call failed or offline, loading verified UAE knowledge fallback:', err);
      // Resilient client fallback
      const fallback = getFallbackGuidance(moduleKey, language, details);
      setCurrentPlan({
        ...fallback,
        sources: VERIFIED_KNOWLEDGE[moduleKey]?.sources || VERIFIED_KNOWLEDGE.everyday_uae.sources,
        verifiedDate: 'October 2026',
        source: 'client_offline_fallback',
        module: moduleKey,
      });
      setGuidanceNotice(
        `Loaded from official UAE verified knowledge base (${err?.message || 'Server connection unavailable'}).`
      );
    } finally {
      setIsLoadingGuidance(false);
      setIsQuestionModalOpen(false);
    }
  };

  // User selects one of the 4 modules
  const handleSelectModule = (mod: ScenarioType) => {
    setActiveModule(mod);
    setIsQuestionModalOpen(true);
  };

  // User submits questions from modal
  const handleQuestionSubmit = (answers: Record<string, string>) => {
    if (!activeModule) return;
    const moduleLabels: Record<ScenarioType, string> = {
      passport_visa: 'Passport & Visa Guidance',
      transport_travel: 'Public Transport & Travel Planning',
      worker_support: 'Worker Rights & Labour Resolution',
      everyday_uae: 'Everyday UAE Living & Housing',
      delayed_salary: 'Salary Delay under WPS',
      contract_issue: 'Employment Documents',
      official_service: 'Official Support Services',
    };
    setLastUserQuery(moduleLabels[activeModule] || 'UAE Guidance Inquiry');
    fetchGuidancePlan(activeModule, answers);
  };

  // User submits a reviewed spoken or typed custom query to the universal AI chat
  const handleQuerySubmit = (queryText: string) => {
    // Reset live transcript and stop speech session cleanly if still listening
    setLiveTranscript('');
    voiceRecognition.stopListening();

    // Intelligently infer the most relevant module
    const lower = queryText.toLowerCase();
    let inferred: ScenarioType = 'everyday_uae';

    if (
      lower.includes('passport') ||
      lower.includes('visa') ||
      lower.includes('bls') ||
      lower.includes('nadra') ||
      lower.includes('gdrfa') ||
      lower.includes('icp') ||
      lower.includes('overstay') ||
      lower.includes('consulate') ||
      lower.includes('embassy') ||
      queryText.includes('جواز') ||
      queryText.includes('تأشيرة') ||
      queryText.includes('فيزا') ||
      queryText.includes('إقامة') ||
      queryText.includes('سفارة') ||
      queryText.includes('قنصلية') ||
      queryText.includes('غرامة')
    ) {
      inferred = 'passport_visa';
    } else if (
      lower.includes('bus') ||
      lower.includes('metro') ||
      lower.includes('tram') ||
      lower.includes('rta') ||
      lower.includes('nol') ||
      lower.includes('darbi') ||
      lower.includes('hafilat') ||
      lower.includes('e100') ||
      lower.includes('e101') ||
      lower.includes("s'hail") ||
      lower.includes('fare') ||
      lower.includes('route') ||
      lower.includes('airport transit') ||
      queryText.includes('مترو') ||
      queryText.includes('باص') ||
      queryText.includes('حافلة') ||
      queryText.includes('حافلات') ||
      queryText.includes('نول') ||
      queryText.includes('درب') ||
      queryText.includes('مواصلات') ||
      queryText.includes('ترام')
    ) {
      inferred = 'transport_travel';
    } else if (
      lower.includes('salary') ||
      lower.includes('wages') ||
      lower.includes('wps') ||
      lower.includes('delayed') ||
      lower.includes('unpaid') ||
      lower.includes('employer') ||
      lower.includes('contract') ||
      lower.includes('mohre') ||
      lower.includes('tawjeeh') ||
      lower.includes('tasheel') ||
      lower.includes('labour') ||
      lower.includes('court') ||
      queryText.includes('راتب') ||
      queryText.includes('رواتب') ||
      queryText.includes('أجور') ||
      queryText.includes('عمال') ||
      queryText.includes('تواجه') ||
      queryText.includes('تسهيل') ||
      queryText.includes('عقد عمل') ||
      queryText.includes('محكمة') ||
      queryText.includes('شكوى')
    ) {
      inferred = 'worker_support';
    } else {
      inferred = 'everyday_uae';
    }

    fetchGuidancePlan(inferred, {}, queryText);
  };

  // Add action steps to personal tracker
  const handleAddStepsToTracker = (steps: GuidanceResult['actionSteps']) => {
    const newItems: FollowUpItem[] = steps.map((s) => ({
      id: `task_${Date.now()}_${s.stepNumber}`,
      title: `Step ${s.stepNumber}: ${s.title}`,
      description: `${s.description} (Tip: ${s.practicalTip})`,
      status: s.stepNumber === 1 ? 'in_progress' : 'pending',
      scenario: activeModule || undefined,
      createdAt: new Date().toLocaleDateString(),
    }));

    const combined = [...newItems, ...trackerItems];
    saveTrackerItems(combined);
    setHasAddedToTracker(true);
  };

  // Tracker Item handlers
  const handleUpdateStatus = (id: string, status: FollowUpStatus) => {
    const updated = trackerItems.map((item) =>
      item.id === id ? { ...item, status } : item
    );
    saveTrackerItems(updated);
  };

  const handleAddCustomItem = (title: string, description: string) => {
    const newItem: FollowUpItem = {
      id: `custom_${Date.now()}`,
      title,
      description,
      status: 'pending',
      createdAt: new Date().toLocaleDateString(),
    };
    saveTrackerItems([newItem, ...trackerItems]);
  };

  const handleDeleteItem = (id: string) => {
    const updated = trackerItems.filter((i) => i.id !== id);
    saveTrackerItems(updated);
  };

  const handleLoadDemoData = (type: 'salary' | 'passport') => {
    const items = getInitialDemoItems(type);
    saveTrackerItems(items);
  };

  const handleClearAllItems = () => {
    saveTrackerItems([]);
  };

  const isRtl = language === 'ur' || language === 'ar';

  return (
    <div
      className={`min-h-screen bg-slate-100 flex flex-col font-sans ${isRtl ? 'rtl' : 'ltr'}`}
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      {/* Top Header */}
      <Header
        language={language}
        onOpenLanguageModal={() => setIsLanguageModalOpen(true)}
        onOpenPrivacyModal={() => setIsPrivacyModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-3xl w-full mx-auto px-4 py-4 pb-28">
        {/* Assistant Tab: Universal Chat Bar + 4 Modules OR Active Plan */}
        {activeTab === 'assistant' && (
          <div className="space-y-4">
            {/* Loading state indicator */}
            {isLoadingGuidance && (
              <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center shadow-xs space-y-3">
                <Loader2 className="w-10 h-10 text-emerald-600 animate-spin mx-auto" />
                <h3 className="text-base font-bold text-slate-800">
                  Formulating Verified Practical Action Plan...
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Cross-referencing verified UAE official regulations and official transit/consular sources in your chosen language.
                </p>
              </div>
            )}

            {/* If plan is generated, display user query card, ActionPlanView, and follow-up chat input */}
            {!isLoadingGuidance && currentPlan && (
              <div className="space-y-4">
                {/* User's recent question banner */}
                {lastUserQuery && (
                  <div className="bg-white border border-slate-200 rounded-2xl p-3.5 shadow-xs flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        <User className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800">
                          Your Question:
                        </span>
                        <p className="text-xs sm:text-sm font-semibold text-slate-900 mt-0.5">
                          "{lastUserQuery}"
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        setCurrentPlan(null);
                        setLastUserQuery(null);
                      }}
                      className="text-xs text-slate-400 hover:text-slate-700 flex items-center gap-1 font-medium cursor-pointer shrink-0"
                      title="Start fresh query"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span className="hidden xs:inline">New Query</span>
                    </button>
                  </div>
                )}

                {/* API / Offline source notice banner */}
                {guidanceNotice && (
                  <div className="bg-amber-50 border border-amber-200/80 text-amber-900 rounded-xl px-3.5 py-2 text-xs flex items-center justify-between gap-2 shadow-2xs">
                    <span className="font-medium">{guidanceNotice}</span>
                    <button
                      onClick={() => setGuidanceNotice(null)}
                      className="text-amber-600 hover:text-amber-950 font-bold px-1 text-sm leading-none cursor-pointer"
                      title="Dismiss notice"
                    >
                      ×
                    </button>
                  </div>
                )}

                {/* The Complete Action Plan with Speaker button, Document Checklist, and Progress */}
                <ActionPlanView
                  plan={currentPlan}
                  language={language}
                  onPlayAudio={(id, text) => audioPlayer.play(id, text, language)}
                  isPlayingAudio={audioPlayer.isPlaying}
                  activeAudioId={audioPlayer.activeItemId}
                  onAddStepsToTracker={handleAddStepsToTracker}
                  hasAddedToTracker={hasAddedToTracker}
                  onResetPlan={() => {
                    setCurrentPlan(null);
                    setLastUserQuery(null);
                  }}
                />

                {/* Follow-up question chat input with mic button beside input */}
                <div className="pt-2">
                  <VoiceAssistantBar
                    language={language}
                    isListening={voiceRecognition.isListening}
                    isSupported={voiceRecognition.isSupported}
                    isTranscribing={voiceRecognition.isTranscribingWithServer}
                    errorMessage={voiceRecognition.errorMessage}
                    onStartListening={voiceRecognition.startListening}
                    onStopListening={voiceRecognition.stopListening}
                    onSubmitQuery={handleQuerySubmit}
                    isLoadingGuidance={isLoadingGuidance}
                    onClearError={voiceRecognition.clearError}
                    onOpenLanguageSelector={() => setIsLanguageModalOpen(true)}
                    liveTranscript={liveTranscript}
                  />
                </div>
              </div>
            )}

            {/* If no plan is active, display Universal Chat Input Bar with Mic Beside Input + 4 Module Cards */}
            {!isLoadingGuidance && !currentPlan && (
              <div className="space-y-4">
                {/* Universal Voice & Text Chat Input Bar */}
                <VoiceAssistantBar
                  language={language}
                  isListening={voiceRecognition.isListening}
                  isSupported={voiceRecognition.isSupported}
                  isTranscribing={voiceRecognition.isTranscribingWithServer}
                  errorMessage={voiceRecognition.errorMessage}
                  onStartListening={voiceRecognition.startListening}
                  onStopListening={voiceRecognition.stopListening}
                  onSubmitQuery={handleQuerySubmit}
                  isLoadingGuidance={isLoadingGuidance}
                  onClearError={voiceRecognition.clearError}
                  onOpenLanguageSelector={() => setIsLanguageModalOpen(true)}
                  liveTranscript={liveTranscript}
                />

                {/* The 4 Core UAE Life Companion Modules */}
                <ModuleCards
                  language={language}
                  onSelectModule={handleSelectModule}
                  onPlayAudio={(id, text) => audioPlayer.play(id, text, language)}
                  isPlayingAudio={audioPlayer.isPlaying}
                  activeAudioId={audioPlayer.activeItemId}
                />

                {/* Mobile / Android Phone Assistance Callout */}
                <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                      <Smartphone className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                        Need mobile or speech guidance?
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Learn how to test voice speech or add this companion app to your phone home screen.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsAndroidGuideModalOpen(true)}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold px-3 py-1.5 rounded-xl text-xs transition-colors cursor-pointer shrink-0"
                  >
                    View Guide
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Directory Tab */}
        {activeTab === 'directory' && (
          <OfficialDirectoryView language={language} />
        )}

        {/* Tracker Tab */}
        {activeTab === 'tracker' && (
          <FollowUpTrackerView
            items={trackerItems}
            language={language}
            onUpdateStatus={handleUpdateStatus}
            onAddItem={handleAddCustomItem}
            onDeleteItem={handleDeleteItem}
            onLoadDemoData={handleLoadDemoData}
            onClearAll={handleClearAllItems}
          />
        )}

        {/* Android Guide Tab */}
        {activeTab === 'guide' && (
          <div className="space-y-4">
            <div className="bg-emerald-900 text-white p-5 rounded-2xl shadow-sm">
              <h2 className="text-base font-bold flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <span>Mobile Setup & Testing Guide</span>
              </h2>
              <p className="text-xs text-emerald-100 mt-1 leading-relaxed">
                Step-by-step instructions for residents and workers using Android or mobile Chrome with multilingual voice recognition and offline support.
              </p>
            </div>

            <button
              onClick={() => setIsAndroidGuideModalOpen(true)}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold p-3.5 rounded-2xl shadow-xs text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-transform active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Open Detailed Step-by-Step Mobile Guide</span>
            </button>
          </div>
        )}
      </main>

      {/* Mobile-First Bottom Navigation Bar */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-white border-t border-slate-200 px-2 py-1.5 shadow-lg max-w-3xl mx-auto">
        <div className="grid grid-cols-4 gap-1">
          <button
            onClick={() => setActiveTab('assistant')}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer ${
              activeTab === 'assistant'
                ? 'text-emerald-700 font-bold bg-emerald-50'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 leading-tight">{t('actionPlanTab', language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('directory')}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer ${
              activeTab === 'directory'
                ? 'text-emerald-700 font-bold bg-emerald-50'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <Landmark className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 leading-tight">{t('officialDirectoryTab', language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('tracker')}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer relative ${
              activeTab === 'tracker'
                ? 'text-emerald-700 font-bold bg-emerald-50'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            <CheckSquare className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 leading-tight">{t('trackerTab', language)}</span>
            {trackerItems.length > 0 && (
              <span className="absolute top-1 right-3 w-4 h-4 bg-emerald-600 text-white rounded-full text-[9px] flex items-center justify-center font-bold">
                {trackerItems.filter((i) => i.status !== 'completed').length}
              </span>
            )}
          </button>

          <button
            onClick={() => setIsAndroidGuideModalOpen(true)}
            className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl text-slate-500 hover:text-slate-800 transition-all cursor-pointer"
          >
            <Smartphone className="w-5 h-5" />
            <span className="text-[10px] mt-0.5 leading-tight">{t('androidGuideTab', language)}</span>
          </button>
        </div>
      </nav>

      {/* Modals */}
      <LanguageSelectorModal
        isOpen={isLanguageModalOpen}
        onClose={() => setIsLanguageModalOpen(false)}
        currentLanguage={language}
        onSelectLanguage={handleSelectLanguage}
        onPlayPreview={(lang, text) => audioPlayer.play(`lang_preview_${lang}`, text, lang)}
        isPlayingPreview={audioPlayer.isPlaying}
        activePreviewLang={
          audioPlayer.activeItemId?.startsWith('lang_preview_')
            ? audioPlayer.activeItemId.replace('lang_preview_', '')
            : null
        }
      />

      {activeModule && (
        <QuestionFlowModal
          isOpen={isQuestionModalOpen}
          onClose={() => setIsQuestionModalOpen(false)}
          scenario={activeModule}
          language={language}
          onSubmit={handleQuestionSubmit}
          isLoading={isLoadingGuidance}
        />
      )}

      <AndroidGuideModal
        isOpen={isAndroidGuideModalOpen}
        onClose={() => setIsAndroidGuideModalOpen(false)}
      />

      <PrivacyModal
        isOpen={isPrivacyModalOpen}
        onClose={() => setIsPrivacyModalOpen(false)}
        language={language}
      />
    </div>
  );
}

// Demo data generator for prototype testing across modules
function getInitialDemoItems(type: 'salary' | 'passport'): FollowUpItem[] {
  if (type === 'passport') {
    return [
      {
        id: 'p_1',
        title: 'Step 1: Check passport expiry & requirements on embassy portal',
        description: 'Verify current validity (must have > 6 months for international travel) on BLS/NADRA portal.',
        status: 'completed',
        createdAt: 'Oct 11, 2026',
      },
      {
        id: 'p_2',
        title: 'Step 2: Book verified embassy appointment online',
        description: 'Book official slot directly on authorized appointment portal; print confirmation voucher.',
        status: 'in_progress',
        createdAt: 'Oct 11, 2026',
      },
      {
        id: 'p_3',
        title: 'Step 3: Prepare original passport & white-background photos',
        description: 'Bring original passport, Emirates ID copy, and 2 passport photos to the service center.',
        status: 'pending',
        createdAt: 'Oct 11, 2026',
      },
    ];
  }

  return [
    {
      id: 's_1',
      title: 'Step 1: Gather ATM salary slip & bank statement',
      description: 'Obtain proof showing last payment date and missing months of pay under WPS.',
      status: 'completed',
      createdAt: 'Oct 11, 2026',
    },
    {
      id: 's_2',
      title: 'Step 2: Send formal written request to employer',
      description: 'Polite inquiry via WhatsApp or letter requesting payment schedule.',
      status: 'in_progress',
      createdAt: 'Oct 11, 2026',
    },
    {
      id: 's_3',
      title: 'Step 3: Call MOHRE 24/7 Helpline (800-60)',
      description: 'Dial toll-free 800-60 to enquire regarding Wages Protection System (WPS) block.',
      status: 'pending',
      createdAt: 'Oct 11, 2026',
    },
    {
      id: 's_4',
      title: 'Step 4: Register labour dispute at Tawjeeh / Court',
      description: 'Exempt from all judicial court fees for claims under AED 100,000.',
      status: 'pending',
      createdAt: 'Oct 11, 2026',
    },
  ];
}
