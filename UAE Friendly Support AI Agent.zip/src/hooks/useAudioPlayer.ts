import { useState, useRef, useCallback, useEffect } from 'react';
import { SupportedLanguage } from '../types';

export function useAudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [activeItemId, setActiveItemId] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Stop any currently playing audio
  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      audioRef.current = null;
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    setIsPlaying(false);
    setIsLoading(false);
    setActiveItemId(null);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stop();
    };
  }, [stop]);

  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const updateVoices = () => {
        setAvailableVoices(window.speechSynthesis.getVoices());
      };
      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  const isSpeechSynthesisSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  const isLanguageSpeechSupported = useCallback((lang: SupportedLanguage): boolean => {
    if (!isSpeechSynthesisSupported) return false;
    const langMap: Record<SupportedLanguage, string> = {
      ar: 'ar',
      ta: 'ta',
      ml: 'ml',
      hi: 'hi',
      ur: 'ur',
      en: 'en',
    };
    const prefix = langMap[lang] || 'en';
    const voices = availableVoices.length > 0 ? availableVoices : (typeof window !== 'undefined' && 'speechSynthesis' in window ? window.speechSynthesis.getVoices() : []);
    // If no voices loaded yet in browser, return true as browser may still speak with default synthesis
    if (voices.length === 0) return true;
    return voices.some(v => v.lang.toLowerCase().startsWith(prefix));
  }, [availableVoices, isSpeechSynthesisSupported]);

  // Fallback to browser SpeechSynthesis
  const playWithBrowserSpeech = useCallback(
    (itemId: string, text: string, lang: SupportedLanguage) => {
      if (!('speechSynthesis' in window)) {
        setIsPlaying(false);
        setIsLoading(false);
        return;
      }

      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utteranceRef.current = utterance;

      const langMap: Record<SupportedLanguage, string> = {
        ar: 'ar-AE',
        ta: 'ta-IN',
        ml: 'ml-IN',
        hi: 'hi-IN',
        ur: 'ur-PK',
        en: 'en-US',
      };

      utterance.lang = langMap[lang] || 'en-US';
      utterance.rate = 0.95; // slightly slower for better comprehension

      // Try to find matching voice
      const voices = window.speechSynthesis.getVoices();
      const matchedVoice = voices.find(
        (v) => v.lang.startsWith(langMap[lang]) || v.lang.toLowerCase().includes(langMap[lang].toLowerCase()) || v.lang.toLowerCase().startsWith(lang)
      );
      if (matchedVoice) {
        utterance.voice = matchedVoice;
      }

      utterance.onstart = () => {
        setIsLoading(false);
        setIsPlaying(true);
        setActiveItemId(itemId);
      };

      utterance.onend = () => {
        setIsPlaying(false);
        setActiveItemId(null);
      };

      utterance.onerror = (e) => {
        console.warn('Browser speech error:', e);
        setIsPlaying(false);
        setIsLoading(false);
        setActiveItemId(null);
      };

      window.speechSynthesis.speak(utterance);
    },
    []
  );

  // Primary playback: Server Gemini TTS with fallback to browser SpeechSynthesis
  const play = useCallback(
    async (itemId: string, text: string, lang: SupportedLanguage) => {
      if (activeItemId === itemId && isPlaying) {
        stop();
        return;
      }

      stop();
      setIsLoading(true);
      setActiveItemId(itemId);

      try {
        const response = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text, language: lang }),
        });

        const data = await response.json();

        if (data.success && data.audioData) {
          const audio = new Audio(data.audioData);
          audioRef.current = audio;

          audio.onplay = () => {
            setIsLoading(false);
            setIsPlaying(true);
          };

          audio.onended = () => {
            setIsPlaying(false);
            setActiveItemId(null);
            audioRef.current = null;
          };

          audio.onerror = () => {
            console.warn('Audio playback error, falling back to browser speech');
            playWithBrowserSpeech(itemId, text, lang);
          };

          await audio.play();
          return;
        }
      } catch (err) {
        console.warn('Server TTS unavailable, falling back to browser speech:', err);
      }

      // If server TTS was not successful, use client speech synthesis
      playWithBrowserSpeech(itemId, text, lang);
    },
    [activeItemId, isPlaying, playWithBrowserSpeech, stop]
  );

  return {
    isPlaying,
    isLoading,
    activeItemId,
    isSpeechSynthesisSupported,
    isLanguageSpeechSupported,
    play,
    stop,
  };
}
