import { useState, useEffect, useRef, useCallback } from 'react';
import { SupportedLanguage } from '../types';

interface VoiceRecognitionOptions {
  language: SupportedLanguage;
  onTranscript: (text: string) => void;
  onError?: (errMessage: string) => void;
}

export function useVoiceRecognition({ language, onTranscript, onError }: VoiceRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isTranscribingWithServer, setIsTranscribingWithServer] = useState(false);

  // Keep references to prevent re-instantiation / abort on component re-renders
  const languageRef = useRef<SupportedLanguage>(language);
  const onTranscriptRef = useRef(onTranscript);
  const onErrorRef = useRef(onError);

  // Recognition lifecycle management
  const recognitionRef = useRef<any>(null);
  const sessionStatusRef = useRef<'idle' | 'starting' | 'listening' | 'stopping'>('idle');
  const isUserInitiatedStopRef = useRef(false);
  const shouldStopWhenStartedRef = useRef(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Update refs on every render without triggering effect cleanups
  useEffect(() => {
    languageRef.current = language;
  }, [language]);

  useEffect(() => {
    onTranscriptRef.current = onTranscript;
  }, [onTranscript]);

  useEffect(() => {
    onErrorRef.current = onError;
  }, [onError]);

  // Map app languages to standard BCP-47 tags
  const getBcp47Code = (lang: SupportedLanguage): string => {
    switch (lang) {
      case 'ar': return 'ar-AE';
      case 'ta': return 'ta-IN';
      case 'ml': return 'ml-IN';
      case 'hi': return 'hi-IN';
      case 'ur': return 'ur-PK';
      case 'en': return 'en-US';
      default: return 'en-US';
    }
  };

  // Check browser support on mount
  useEffect(() => {
    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    const hasMediaSupport = Boolean(
      typeof navigator !== 'undefined' &&
      navigator.mediaDevices &&
      navigator.mediaDevices.getUserMedia
    );

    if (SpeechRecognitionClass || hasMediaSupport) {
      setIsSupported(true);
    } else {
      setIsSupported(false);
    }

    // Cleanup on unmount only
    return () => {
      if (recognitionRef.current) {
        try {
          isUserInitiatedStopRef.current = true;
          sessionStatusRef.current = 'stopping';
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
        recognitionRef.current = null;
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        try {
          mediaRecorderRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  // Safe SpeechRecognition factory
  const createSpeechRecognition = useCallback(() => {
    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognitionClass) return null;

    try {
      const recognition = new SpeechRecognitionClass();
      recognition.continuous = false; // continuous: false is more reliable across mobile browsers
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        sessionStatusRef.current = 'listening';
        setIsListening(true);
        setErrorMessage(null);

        // If user tapped stop while starting was in progress, stop gracefully now
        if (shouldStopWhenStartedRef.current) {
          shouldStopWhenStartedRef.current = false;
          try {
            recognition.stop();
          } catch {
            // ignore
          }
        }
      };

      recognition.onresult = (event: any) => {
        let fullTranscript = '';
        for (let i = 0; i < event.results.length; ++i) {
          const item = event.results[i];
          if (item && item[0]) {
            fullTranscript += item[0].transcript;
          }
        }

        const trimmed = fullTranscript.trim();
        if (trimmed && onTranscriptRef.current) {
          onTranscriptRef.current(trimmed);
        }
      };

      recognition.onerror = (event: any) => {
        const errorType = event.error;
        sessionStatusRef.current = 'idle';
        setIsListening(false);

        // Handle specific error types
        if (errorType === 'aborted') {
          // If the user intentionally stopped recognition, do not show any error message
          if (isUserInitiatedStopRef.current) {
            isUserInitiatedStopRef.current = false;
            return;
          }
          // If aborted by the system/browser, show a friendly retry message
          const msg = 'Speech input stopped. Tap the microphone to speak again.';
          setErrorMessage(msg);
          onErrorRef.current?.(msg);
          return;
        }

        if (errorType === 'not-allowed' || errorType === 'service-not-allowed') {
          const msg = 'Microphone permission was denied. Please allow microphone permissions in your browser address bar settings to use voice.';
          setErrorMessage(msg);
          onErrorRef.current?.(msg);
          return;
        }

        if (errorType === 'no-speech') {
          const msg = 'No speech detected. Tap the microphone to try again.';
          setErrorMessage(msg);
          return;
        }

        if (errorType === 'network') {
          const msg = 'Network error during speech recognition. You can type your question in the chat input.';
          setErrorMessage(msg);
          onErrorRef.current?.(msg);
          return;
        }

        if (errorType === 'audio-capture') {
          const msg = 'No microphone found on your device. Please verify your microphone or use text typing.';
          setErrorMessage(msg);
          onErrorRef.current?.(msg);
          return;
        }

        const msg = `Voice input notice (${errorType}). You can still type your question below.`;
        setErrorMessage(msg);
        onErrorRef.current?.(msg);
      };

      recognition.onend = () => {
        sessionStatusRef.current = 'idle';
        setIsListening(false);
        isUserInitiatedStopRef.current = false;
        shouldStopWhenStartedRef.current = false;
      };

      return recognition;
    } catch (err) {
      console.warn('SpeechRecognition creation failed:', err);
      return null;
    }
  }, []);

  const startListening = useCallback(async () => {
    setErrorMessage(null);
    isUserInitiatedStopRef.current = false;
    shouldStopWhenStartedRef.current = false;

    // Prevent duplicate sessions
    if (sessionStatusRef.current === 'starting' || sessionStatusRef.current === 'listening') {
      return;
    }

    const SpeechRecognitionClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    // 1. Try Native Web Speech API
    if (SpeechRecognitionClass) {
      // Check microphone permissions ahead of time if Permissions API is supported
      if (typeof navigator !== 'undefined' && navigator.permissions && navigator.permissions.query) {
        try {
          const perm = await navigator.permissions.query({ name: 'microphone' as any });
          if (perm.state === 'denied') {
            const msg = 'Microphone access is blocked in your browser settings. Please allow microphone access or type your question below.';
            setErrorMessage(msg);
            onErrorRef.current?.(msg);
            setIsListening(false);
            return;
          }
        } catch {
          // Some browsers do not support microphone in permissions.query; continue gracefully
        }
      }

      // Clean up any stale recognition instance before starting fresh
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
        recognitionRef.current = null;
      }

      const recognition = createSpeechRecognition();
      if (recognition) {
        recognitionRef.current = recognition;

        // Set the selected language before starting recognition
        const targetLangCode = getBcp47Code(languageRef.current);
        recognition.lang = targetLangCode;

        sessionStatusRef.current = 'starting';

        try {
          recognition.start();
          return;
        } catch (startErr: any) {
          console.warn('SpeechRecognition.start() error:', startErr);
          sessionStatusRef.current = 'idle';
          setIsListening(false);

          if (startErr.name === 'InvalidStateError') {
            // Already started; ignore duplicate
            return;
          }

          if (startErr.name === 'NotAllowedError') {
            const msg = 'Microphone permission was denied. Please allow microphone permissions or use text typing.';
            setErrorMessage(msg);
            onErrorRef.current?.(msg);
            return;
          }
        }
      }
    }

    // 2. Fallback to MediaRecorder & server transcription if SpeechRecognition is not available
    if (typeof navigator !== 'undefined' && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        sessionStatusRef.current = 'starting';
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioChunksRef.current = [];
        const recorder = new MediaRecorder(stream);

        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunksRef.current.push(e.data);
        };

        recorder.onstart = () => {
          sessionStatusRef.current = 'listening';
          setIsListening(true);
        };

        recorder.onstop = async () => {
          sessionStatusRef.current = 'idle';
          setIsListening(false);

          if (audioChunksRef.current.length === 0) return;

          setIsTranscribingWithServer(true);
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });

          const reader = new FileReader();
          reader.readAsDataURL(audioBlob);
          reader.onloadend = async () => {
            const base64Audio = reader.result as string;
            try {
              const res = await fetch('/api/transcribe', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  audioBase64: base64Audio,
                  mimeType: 'audio/webm',
                  language: languageRef.current,
                }),
              });
              const data = await res.json();
              if (data.success && data.text) {
                onTranscriptRef.current?.(data.text);
              } else {
                setErrorMessage('Could not recognize voice. Please try typing your question.');
              }
            } catch {
              setErrorMessage('Transcription server error. Please type your question.');
            } finally {
              setIsTranscribingWithServer(false);
            }
          };

          // Release all tracks
          stream.getTracks().forEach((track) => track.stop());
        };

        recorder.start();
        mediaRecorderRef.current = recorder;
      } catch (micErr: any) {
        sessionStatusRef.current = 'idle';
        setIsListening(false);
        const msg = micErr.name === 'NotAllowedError'
          ? 'Microphone permission denied. Please allow microphone permissions in browser settings.'
          : 'Microphone access failed. Please type your question in the chat box.';
        setErrorMessage(msg);
        onErrorRef.current?.(msg);
      }
    } else {
      setIsListening(false);
      sessionStatusRef.current = 'idle';
      setErrorMessage('Speech recognition is not supported on this browser. You can type your question in the chat box.');
    }
  }, [createSpeechRecognition]);

  const stopListening = useCallback(() => {
    isUserInitiatedStopRef.current = true;

    // Do NOT call stop() or abort() immediately if recognition is still in 'starting' state
    if (sessionStatusRef.current === 'starting') {
      shouldStopWhenStartedRef.current = true;
      return;
    }

    if (recognitionRef.current && sessionStatusRef.current === 'listening') {
      sessionStatusRef.current = 'stopping';
      try {
        recognitionRef.current.stop();
      } catch {
        // ignore
      }
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      sessionStatusRef.current = 'stopping';
      try {
        mediaRecorderRef.current.stop();
      } catch {
        // ignore
      }
    }

    setIsListening(false);
  }, []);

  const clearError = useCallback(() => {
    setErrorMessage(null);
  }, []);

  return {
    isListening,
    isSupported,
    isTranscribingWithServer,
    errorMessage,
    clearError,
    startListening,
    stopListening,
  };
}
