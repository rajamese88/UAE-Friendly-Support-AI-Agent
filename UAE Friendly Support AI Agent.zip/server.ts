import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { VERIFIED_KNOWLEDGE, getFallbackGuidance } from './src/data/verifiedKnowledge';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize server-side Gemini client
const apiKey = process.env.GEMINI_API_KEY || '';
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

app.use(express.json({ limit: '10mb' }));

// API: Health check & API status
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    app: 'UAE Life Companion AI',
    hasApiKey: Boolean(apiKey),
    timestamp: new Date().toISOString(),
  });
});

// API: Generate Action Plan using Gemini 3.8 Flash
app.post('/api/guidance', async (req: Request, res: Response) => {
  const { scenario, module, language, details, customQuery } = req.body;

  const langNames: Record<string, string> = {
    ar: 'Arabic (العربية)',
    ta: 'Tamil (தமிழ்)',
    ml: 'Malayalam (മലയാളം)',
    hi: 'Hindi (हिन्दी)',
    ur: 'Urdu (اردو)',
    en: 'English',
  };

  const targetLang = langNames[language] || 'English';

  // Determine active module / scenario
  const effectiveKey = (module || scenario || 'everyday_uae') as string;
  const verifiedBase = VERIFIED_KNOWLEDGE[effectiveKey] || VERIFIED_KNOWLEDGE.everyday_uae;

  // If AI client is configured, call Gemini 3.8 Flash
  if (ai) {
    try {
      const prompt = `
You are the intelligence engine of "UAE Life Companion AI".
Your role: Provide practical, empathetic, step-by-step everyday guidance to UAE residents, workers, visitors, and families across 4 core areas:
1. Passport & Visa Guidance (tailored by nationality/embassy, ICP/GDRFA)
2. Public Transport & Travel (RTA Metro, Nol cards, Intercity buses E100/E101, Abu Dhabi ITC Darbi)
3. Worker Support & Labour Rights (MOHRE 800-60, WPS 14-day rule, passport retention prohibition, court fee exemption)
4. Everyday UAE Life & Emergency (Ejari rent, DHA/DoH health insurance, emergency 999/998/997/901)

CRITICAL BOUNDARIES:
- This is an independent guidance assistant, NOT a UAE government entity, embassy, or law firm.
- Never claim government affiliation or guarantee legal, visa, or travel outcomes.
- Never invent phone numbers, legal fees, schedules, or deadlines.
- If live transport delays or real-time schedules cannot be verified, clearly advise checking official apps (RTA S'hail, ITC Darbi).
- When discussing passports or embassy services, remember different nationalities use their own distinct embassy procedures (e.g. BLS for India, NADRA/Consulate for Pakistan). Never assume all countries have the same process.
- Output MUST be in the worker's selected language: ${targetLang}.
- For Arabic, use standard clear Arabic (الفصحى المعاصرة). For Urdu, use proper Urdu script. For Tamil, use Tamil script. For Malayalam, use Malayalam script. For Hindi, use Devanagari script.

USER REQUEST CONTEXT:
- Category / Module: ${effectiveKey}
- User Details Provided: ${JSON.stringify(details || {})}
- User Query: ${customQuery || 'None'}

VERIFIED OFFICIAL CONTEXT TO GROUND YOUR RESPONSE:
${JSON.stringify(verifiedBase.verifiedFacts, null, 2)}

OFFICIAL VERIFIED CONTACTS:
- Emergencies: Police (999), Ambulance (998), Fire (997), Non-Emergency Police (901)
- MOHRE Labour Helpline: 800-60
- RTA Dubai Public Transport: 800-9090
- ICP Federal Visas: 600-522222 | GDRFA Dubai Amer: 800-5111
- Dubai Health Authority (DHA): 800-342 | Dubai Land Department (Ejari): 800-4488

Generate a structured response with:
1. summary: A 2-sentence empathetic summary of their situation/query in ${targetLang}.
2. plainExplanation: A gentle, clear 2-3 sentence explanation of official rules and practical options in simple terms.
3. actionSteps: 3 to 4 sequential, realistic steps. Each must have:
   - stepNumber (integer)
   - title (short, clear title in ${targetLang})
   - description (clear explanation in ${targetLang})
   - urgency ("immediate" | "next_step" | "official_filing")
   - practicalTip (a calm, actionable tip)
4. requiredDocuments: 3 to 4 documents or items to gather (e.g. Passport copy, Nol card, tenancy contract, Emirates ID). Never ask for passwords, bank card numbers, or unnecessary sensitive data!
   - name (document title in ${targetLang})
   - whyNeeded (in ${targetLang})
   - howToGet (in ${targetLang})
5. verifiedFacts: 2 to 3 bullet points of confirmed UAE official rules in ${targetLang}.
6. practicalAdvice: 2 practical non-legal tips.
7. uncertainties: A clear sentence explaining any uncertainties or authority to contact.
8. disclaimer: A clear statement in ${targetLang} stating this is independent general guidance, not legal advice or official government representation.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              plainExplanation: { type: Type.STRING },
              actionSteps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    stepNumber: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    urgency: { type: Type.STRING },
                    practicalTip: { type: Type.STRING },
                  },
                  required: ['stepNumber', 'title', 'description', 'urgency', 'practicalTip'],
                },
              },
              requiredDocuments: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    whyNeeded: { type: Type.STRING },
                    howToGet: { type: Type.STRING },
                  },
                  required: ['name', 'whyNeeded', 'howToGet'],
                },
              },
              verifiedFacts: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              practicalAdvice: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              uncertainties: { type: Type.STRING },
              disclaimer: { type: Type.STRING },
            },
            required: [
              'summary',
              'plainExplanation',
              'actionSteps',
              'requiredDocuments',
              'verifiedFacts',
              'practicalAdvice',
              'uncertainties',
              'disclaimer',
            ],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json({
        success: true,
        data: {
          ...parsed,
          sources: verifiedBase.sources,
          verifiedDate: 'October 2026',
          source: 'gemini-3.8-flash',
          module: effectiveKey,
          aiLive: true,
        },
      });
    } catch (err: unknown) {
      console.error('Gemini guidance error:', err);
    }
  }

  // Resilient Fallback built with verified UAE official guidelines
  const fallbackData = getFallbackGuidance(effectiveKey, language, details);
  return res.json({
    success: true,
    data: {
      ...fallbackData,
      sources: verifiedBase.sources,
      verifiedDate: 'October 2026',
      source: apiKey ? 'verified_knowledge_base' : 'verified_knowledge_base_no_api_key',
      module: effectiveKey,
      aiLive: false,
    },
  });
});

// API: Text-to-Speech using gemini-3.8-flash-lite-tts
app.post('/api/tts', async (req: Request, res: Response) => {
  const { text } = req.body;

  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Text is required for TTS' });
  }

  const cleanText = text.slice(0, 500);

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: cleanText,
                speechMetadata: {
                  style: 'Gentle, clear, supportive, at an accessible speaking pace',
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        return res.json({
          success: true,
          audioData: `data:audio/wav;base64,${base64Audio}`,
          provider: 'gemini-tts',
        });
      }
    } catch (ttsErr: unknown) {
      console.warn('Gemini TTS error, falling back to browser speech:', ttsErr);
    }
  }

  return res.json({
    success: false,
    fallbackToBrowserSpeech: true,
    message: 'Speech synthesis fallback enabled',
  });
});

// API: Audio Transcription using gemini-3.5-transcribe
app.post('/api/transcribe', async (req: Request, res: Response) => {
  const { audioBase64, mimeType } = req.body;

  if (!audioBase64) {
    return res.status(400).json({ error: 'Audio data is required' });
  }

  if (ai) {
    try {
      const audioPart = {
        inlineData: {
          mimeType: mimeType || 'audio/webm',
          data: audioBase64.replace(/^data:[^;]+;base64,/, ''),
        },
      };

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-transcribe',
        contents: {
          parts: [
            audioPart,
            {
              text: 'Transcribe this voice audio accurately in the language spoken (it could be Arabic, Tamil, Malayalam, Hindi, Urdu, or English). Return only the transcribed text without commentary.',
            },
          ],
        },
      });

      return res.json({
        success: true,
        text: response.text?.trim() || '',
      });
    } catch (err: unknown) {
      console.error('Transcription error:', err);
      return res.status(500).json({ error: 'Failed to transcribe audio' });
    }
  }

  return res.status(503).json({ error: 'Speech transcription service currently unavailable' });
});

// In production, serve built frontend; in dev, mount Vite middleware
async function setupVite() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, () => {
    console.log(`UAE Life Companion running on port ${PORT}`);
  });
}

setupVite();
