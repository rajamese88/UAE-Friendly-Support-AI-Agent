import type { Handler, HandlerEvent } from '@netlify/functions';
import { GoogleGenAI, Type } from '@google/genai';
import { VERIFIED_KNOWLEDGE, getFallbackGuidance } from '../../src/data/verifiedKnowledge';

const CORS_HEADERS = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

export const handler: Handler = async (event: HandlerEvent) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: CORS_HEADERS,
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: 'Method Not Allowed. Use POST.' }),
    };
  }

  let body: any = {};
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: 'Invalid JSON request body.' }),
    };
  }

  const { scenario, module, language = 'en', details, customQuery } = body;
  const effectiveKey = (module || scenario || 'everyday_uae') as string;
  const verifiedBase = VERIFIED_KNOWLEDGE[effectiveKey] || VERIFIED_KNOWLEDGE.everyday_uae;

  const langNames: Record<string, string> = {
    ar: 'Arabic (العربية)',
    ta: 'Tamil (தமிழ்)',
    ml: 'Malayalam (മലയാളം)',
    hi: 'Hindi (हिन्दी)',
    ur: 'Urdu (اردو)',
    en: 'English',
  };
  const targetLang = langNames[language] || 'English';

  const apiKey = process.env.GEMINI_API_KEY || '';

  // If Gemini API key is configured in Netlify environment variables, call Gemini
  if (apiKey) {
    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build-netlify',
          },
        },
      });

      const prompt = `
You are the intelligence engine of "UAE Life Companion AI".
Your role: Provide practical, empathetic, step-by-step everyday guidance to UAE residents, workers, visitors, and families across 4 core areas:
1. Passport & Visa Guidance (tailored by nationality/embassy, ICP/GDRFA)
2. Public Transport & Travel (RTA Metro, Nol cards, Intercity buses E100/E101, Abu Dhabi ITC Darbi)
3. Worker Support & Labour Rights (MOHRE 800-60, WPS 14-day rule, passport retention prohibition, court fee exemption)
4. Everyday UAE Life & Emergency (Ejari rent, DHA/DoH health insurance, emergency 999/998/997/901)

CRITICAL BOUNDARIES:
- This is an independent guidance assistant, NOT a UAE government entity, embassy, or law firm.
- Never claim government affiliation or guarantee legal, visa, or travel outcomes.
- Never invent phone numbers, legal fees, schedules, or deadlines.
- If live transport delays or real-time schedules cannot be verified, clearly advise checking official apps (RTA S'hail, ITC Darbi).
- When discussing passports or embassy services, remember different nationalities use their own distinct embassy procedures (e.g. BLS for India, NADRA/Consulate for Pakistan). Never assume all countries have the same process.
- Output MUST be in the user's selected language: ${targetLang}.
- For Arabic, use standard clear Arabic (الفصحى المعاصرة). For Urdu, use proper Urdu script. For Tamil, use Tamil script. For Malayalam, use Malayalam script. For Hindi, use Devanagari script.

USER REQUEST CONTEXT:
- Category / Module: ${effectiveKey}
- User Details Provided: ${JSON.stringify(details || {})}
- User Query: ${customQuery || 'None'}

VERIFIED OFFICIAL CONTEXT TO GROUND YOUR RESPONSE:
${JSON.stringify(verifiedBase.verifiedFacts, null, 2)}

OFFICIAL VERIFIED CONTACTS:
- Emergencies: Police (999), Ambulance (998), Fire (997), Non-Emergency Police (901)
- MOHRE Labour Helpline: 800-60
- RTA Dubai Public Transport: 800-9090
- ICP Federal Visas: 600-522222 | GDRFA Dubai Amer: 800-5111
- Dubai Health Authority (DHA): 800-342 | Dubai Land Department (Ejari): 800-4488

Generate a structured response with:
1. summary: A 2-sentence empathetic summary of their situation/query in ${targetLang}.
2. plainExplanation: A gentle, clear 2-3 sentence explanation of official rules and practical options in simple terms.
3. actionSteps: 3 to 4 sequential, realistic steps. Each must have:
   - stepNumber (integer)
   - title (short, clear title in ${targetLang})
   - description (clear explanation in ${targetLang})
   - urgency ("immediate" | "next_step" | "official_filing")
   - practicalTip (a calm, actionable tip)
4. requiredDocuments: 3 to 4 documents or items to gather (e.g. Passport copy, Nol card, tenancy contract, Emirates ID). Never ask for passwords, bank card numbers, or unnecessary sensitive data!
   - name (document title in ${targetLang})
   - whyNeeded (in ${targetLang})
   - howToGet (in ${targetLang})
5. verifiedFacts: 2 to 3 bullet points of confirmed UAE official rules in ${targetLang}.
6. practicalAdvice: 2 practical non-legal tips.
7. uncertainties: A clear sentence explaining any uncertainties or authority to contact.
8. disclaimer: A clear statement in ${targetLang} stating this is independent general guidance, not legal advice or official government representation.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              plainExplanation: { type: Type.STRING },
              actionSteps: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    stepNumber: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    urgency: { type: Type.STRING },
                    practicalTip: { type: Type.STRING },
                  },
                  required: ['stepNumber', 'title', 'description', 'urgency', 'practicalTip'],
                },
              },
              requiredDocuments: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    whyNeeded: { type: Type.STRING },
                    howToGet: { type: Type.STRING },
                  },
                  required: ['name', 'whyNeeded', 'howToGet'],
                },
              },
              verifiedFacts: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              practicalAdvice: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              uncertainties: { type: Type.STRING },
              disclaimer: { type: Type.STRING },
            },
            required: [
              'summary',
              'plainExplanation',
              'actionSteps',
              'requiredDocuments',
              'verifiedFacts',
              'practicalAdvice',
              'uncertainties',
              'disclaimer',
            ],
          },
        },
      });

      const parsed = JSON.parse(response.text || '{}');
      return {
        statusCode: 200,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: true,
          data: {
            ...parsed,
            sources: verifiedBase.sources,
            verifiedDate: 'October 2026',
            source: 'gemini-3.8-flash',
            module: effectiveKey,
            aiLive: true,
          },
        }),
      };
    } catch (aiErr: unknown) {
      console.warn('Netlify Function Gemini guidance error, falling back to verified knowledge:', aiErr);
    }
  }

  // Resilient fallback with verified official UAE knowledge base
  const fallback = getFallbackGuidance(effectiveKey, language, details);
  return {
    statusCode: 200,
    headers: CORS_HEADERS,
    body: JSON.stringify({
      success: true,
      data: {
        ...fallback,
        sources: verifiedBase.sources,
        verifiedDate: 'October 2026',
        source: apiKey ? 'verified_knowledge_base' : 'verified_knowledge_base_no_api_key',
        module: effectiveKey,
        aiLive: false,
        aiNotice: apiKey
          ? 'Live AI service temporarily unavailable; response loaded from official UAE verified knowledge base.'
          : 'GEMINI_API_KEY is not yet configured in Netlify Environment Variables. Serving official verified UAE guidance.',
      },
    }),
  };
};
